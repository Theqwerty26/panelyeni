-- Helpers
CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role='super_admin')
$$;

CREATE OR REPLACE FUNCTION public.is_admin_or_super(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id=_user_id AND role IN ('admin','super_admin'))
$$;

REVOKE EXECUTE ON FUNCTION public.is_super_admin(uuid) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.is_admin_or_super(uuid) FROM PUBLIC;

-- Extend clients
ALTER TABLE public.clients
  ADD COLUMN IF NOT EXISTS assigned_admin_id uuid,
  ADD COLUMN IF NOT EXISTS ai_chat_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS data_source text NOT NULL DEFAULT 'manual' CHECK (data_source IN ('api','manual','mixed')),
  ADD COLUMN IF NOT EXISTS manual_lock boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS logo_url text;

-- Extend ad_metrics
ALTER TABLE public.ad_metrics
  ADD COLUMN IF NOT EXISTS conversion_value numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS campaign_status text NOT NULL DEFAULT 'enabled',
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'manual' CHECK (source IN ('api','manual'));

-- app_settings
CREATE TABLE IF NOT EXISTS public.app_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "settings_super_admin_all" ON public.app_settings FOR ALL TO authenticated
  USING (public.is_super_admin(auth.uid())) WITH CHECK (public.is_super_admin(auth.uid()));
CREATE POLICY "settings_public_branding" ON public.app_settings FOR SELECT TO authenticated
  USING (key IN ('general','branding'));

INSERT INTO public.app_settings(key, value) VALUES
  ('general', '{"company_name":"Time SEO","default_language":"tr","timezone":"Europe/Istanbul","currency":"TRY","date_format":"DD/MM/YYYY"}'::jsonb),
  ('branding', '{"primary_color":"#6366f1","secondary_color":"#8b5cf6","agency_name":"Time SEO","default_theme":"dark"}'::jsonb),
  ('security', '{"two_factor_enabled":false,"password_min_length":8,"session_timeout_minutes":120,"allowed_roles":["super_admin","admin","client"]}'::jsonb),
  ('export', '{"include_logo":true,"include_charts":true,"footer_text":""}'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- google_ads_settings
CREATE TABLE IF NOT EXISTS public.google_ads_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mcc_customer_id text,
  developer_token text,
  client_id text,
  client_secret text,
  refresh_token text,
  login_customer_id text,
  api_version text DEFAULT 'v17',
  test_customer_id text,
  last_tested_at timestamptz,
  last_test_status text,
  last_test_message text,
  last_test_account_name text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  singleton boolean NOT NULL DEFAULT true,
  CONSTRAINT google_ads_settings_singleton UNIQUE (singleton)
);
ALTER TABLE public.google_ads_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "gads_super_admin_all" ON public.google_ads_settings FOR ALL TO authenticated
  USING (public.is_super_admin(auth.uid())) WITH CHECK (public.is_super_admin(auth.uid()));
INSERT INTO public.google_ads_settings(singleton) VALUES (true) ON CONFLICT DO NOTHING;

-- ai_provider_settings
CREATE TABLE IF NOT EXISTS public.ai_provider_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT false,
  api_key text,
  model text,
  base_url text,
  max_tokens integer DEFAULT 1024,
  temperature numeric DEFAULT 0.7,
  system_prompt text DEFAULT 'You are a helpful Google Ads marketing analyst.',
  is_default boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.ai_provider_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "ai_super_admin_all" ON public.ai_provider_settings FOR ALL TO authenticated
  USING (public.is_super_admin(auth.uid())) WITH CHECK (public.is_super_admin(auth.uid()));

INSERT INTO public.ai_provider_settings(provider, enabled, model, is_default) VALUES
  ('lovable', true, 'google/gemini-2.5-flash', true),
  ('openai', false, 'gpt-4o-mini', false),
  ('anthropic', false, 'claude-3-5-sonnet-20241022', false),
  ('gemini', false, 'gemini-1.5-pro', false),
  ('deepseek', false, 'deepseek-chat', false),
  ('custom', false, NULL, false)
ON CONFLICT (provider) DO NOTHING;

-- audit_logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid,
  user_email text,
  role text,
  action text NOT NULL,
  ip_address text,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audit_super_admin_select" ON public.audit_logs FOR SELECT TO authenticated
  USING (public.is_super_admin(auth.uid()));
CREATE POLICY "audit_authenticated_insert" ON public.audit_logs FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);
CREATE INDEX IF NOT EXISTS audit_logs_created_at_idx ON public.audit_logs(created_at DESC);

-- notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  message text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif_owner_all" ON public.notifications FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- product_metrics
CREATE TABLE IF NOT EXISTS public.product_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  date date NOT NULL,
  product_id text,
  product_title text NOT NULL,
  product_category text,
  brand text,
  price numeric DEFAULT 0,
  merchant_center_id text,
  impressions integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  cost numeric NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  conversion_value numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.product_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "product_admin_all" ON public.product_metrics FOR ALL TO authenticated
  USING (public.is_admin_or_super(auth.uid())) WITH CHECK (public.is_admin_or_super(auth.uid()));
CREATE POLICY "product_client_select_own" ON public.product_metrics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.clients c WHERE c.id = product_metrics.client_id AND c.user_id = auth.uid()));
CREATE INDEX IF NOT EXISTS product_metrics_client_date_idx ON public.product_metrics(client_id, date DESC);

-- keyword_metrics
CREATE TABLE IF NOT EXISTS public.keyword_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  date date NOT NULL,
  keyword text NOT NULL,
  match_type text DEFAULT 'broad',
  campaign_name text,
  impressions integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  cost numeric NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  conversion_value numeric NOT NULL DEFAULT 0,
  quality_score integer,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.keyword_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "keyword_admin_all" ON public.keyword_metrics FOR ALL TO authenticated
  USING (public.is_admin_or_super(auth.uid())) WITH CHECK (public.is_admin_or_super(auth.uid()));
CREATE POLICY "keyword_client_select_own" ON public.keyword_metrics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.clients c WHERE c.id = keyword_metrics.client_id AND c.user_id = auth.uid()));
CREATE INDEX IF NOT EXISTS keyword_metrics_client_date_idx ON public.keyword_metrics(client_id, date DESC);

-- audience_metrics
CREATE TABLE IF NOT EXISTS public.audience_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.clients(id) ON DELETE CASCADE,
  date date NOT NULL,
  audience_name text NOT NULL,
  campaign_name text,
  impressions integer NOT NULL DEFAULT 0,
  clicks integer NOT NULL DEFAULT 0,
  cost numeric NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  conversion_value numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.audience_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY "audience_admin_all" ON public.audience_metrics FOR ALL TO authenticated
  USING (public.is_admin_or_super(auth.uid())) WITH CHECK (public.is_admin_or_super(auth.uid()));
CREATE POLICY "audience_client_select_own" ON public.audience_metrics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.clients c WHERE c.id = audience_metrics.client_id AND c.user_id = auth.uid()));

-- Update existing policies for super_admin coverage
DROP POLICY IF EXISTS clients_admin_all ON public.clients;
CREATE POLICY "clients_admin_or_super_all" ON public.clients FOR ALL TO authenticated
  USING (public.is_admin_or_super(auth.uid())) WITH CHECK (public.is_admin_or_super(auth.uid()));

DROP POLICY IF EXISTS metrics_admin_all ON public.ad_metrics;
CREATE POLICY "metrics_admin_or_super_all" ON public.ad_metrics FOR ALL TO authenticated
  USING (public.is_admin_or_super(auth.uid())) WITH CHECK (public.is_admin_or_super(auth.uid()));

-- handle_new_user: first user = super_admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_count int;
BEGIN
  SELECT count(*) INTO user_count FROM auth.users;
  IF user_count <= 1 THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (new.id, 'super_admin') ON CONFLICT DO NOTHING;
  ELSE
    INSERT INTO public.user_roles(user_id, role) VALUES (new.id, 'client') ON CONFLICT DO NOTHING;
    UPDATE public.clients SET user_id = new.id WHERE email = new.email;
  END IF;
  RETURN new;
END; $$;

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

DROP TRIGGER IF EXISTS app_settings_touch ON public.app_settings;
CREATE TRIGGER app_settings_touch BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
DROP TRIGGER IF EXISTS gads_touch ON public.google_ads_settings;
CREATE TRIGGER gads_touch BEFORE UPDATE ON public.google_ads_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
DROP TRIGGER IF EXISTS ai_touch ON public.ai_provider_settings;
CREATE TRIGGER ai_touch BEFORE UPDATE ON public.ai_provider_settings FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();