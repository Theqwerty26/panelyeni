
-- SEO provider settings (SEMrush / Ahrefs / SerpAPI)
CREATE TABLE public.seo_provider_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL UNIQUE,
  enabled boolean NOT NULL DEFAULT false,
  base_url text,
  default_database text,
  rate_limit_per_minute integer DEFAULT 30,
  last_tested_at timestamptz,
  last_test_status text,
  last_test_message text,
  config jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.seo_provider_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY seo_prov_super_all ON public.seo_provider_settings FOR ALL TO authenticated
  USING (is_super_admin(auth.uid())) WITH CHECK (is_super_admin(auth.uid()));
INSERT INTO public.seo_provider_settings(provider, base_url) VALUES
  ('semrush','https://api.semrush.com'),
  ('ahrefs','https://api.ahrefs.com/v3'),
  ('serpapi','https://serpapi.com')
ON CONFLICT (provider) DO NOTHING;

-- SERP rank tracking results
CREATE TABLE public.serp_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  keyword text NOT NULL,
  country text DEFAULT 'tr',
  language text DEFAULT 'tr',
  device text NOT NULL DEFAULT 'desktop',
  search_engine text NOT NULL DEFAULT 'google',
  position integer,
  previous_position integer,
  url text,
  search_volume integer,
  cpc numeric DEFAULT 0,
  competition numeric DEFAULT 0,
  difficulty integer,
  provider text NOT NULL DEFAULT 'manual',
  fetched_at timestamptz NOT NULL DEFAULT now(),
  raw jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_serp_client_kw ON public.serp_results(client_id, keyword);
CREATE INDEX idx_serp_fetched ON public.serp_results(fetched_at DESC);
ALTER TABLE public.serp_results ENABLE ROW LEVEL SECURITY;
CREATE POLICY serp_admin_all ON public.serp_results FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY serp_client_select ON public.serp_results FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = serp_results.client_id AND c.user_id = auth.uid()));

-- SERP competitor domains
CREATE TABLE public.serp_competitors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  domain text NOT NULL,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(client_id, domain)
);
ALTER TABLE public.serp_competitors ENABLE ROW LEVEL SECURITY;
CREATE POLICY serpcomp_admin_all ON public.serp_competitors FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY serpcomp_client_select ON public.serp_competitors FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = serp_competitors.client_id AND c.user_id = auth.uid()));

-- SMTP settings
CREATE TABLE public.smtp_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton boolean NOT NULL DEFAULT true UNIQUE,
  host text,
  port integer DEFAULT 587,
  username text,
  password text,
  from_email text,
  from_name text,
  secure boolean DEFAULT false,
  enabled boolean NOT NULL DEFAULT false,
  last_tested_at timestamptz,
  last_test_status text,
  last_test_message text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.smtp_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY smtp_super_all ON public.smtp_settings FOR ALL TO authenticated
  USING (is_super_admin(auth.uid())) WITH CHECK (is_super_admin(auth.uid()));
INSERT INTO public.smtp_settings(singleton) VALUES (true) ON CONFLICT DO NOTHING;

-- Email templates
CREATE TABLE public.email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  name text NOT NULL,
  subject text NOT NULL,
  html text NOT NULL DEFAULT '',
  text text DEFAULT '',
  variables jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_system boolean NOT NULL DEFAULT false,
  enabled boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY etpl_super_all ON public.email_templates FOR ALL TO authenticated
  USING (is_super_admin(auth.uid())) WITH CHECK (is_super_admin(auth.uid()));
CREATE POLICY etpl_admin_read ON public.email_templates FOR SELECT TO authenticated
  USING (is_admin_or_super(auth.uid()));

INSERT INTO public.email_templates(key, name, subject, html, variables, is_system) VALUES
('password_reset','Şifre sıfırlama','Şifrenizi sıfırlayın',
  '<h2>Şifre Sıfırlama</h2><p>Merhaba {{name}},</p><p>Şifrenizi sıfırlamak için <a href="{{reset_url}}">tıklayın</a>.</p>',
  '["name","reset_url"]'::jsonb, true),
('new_password','Yeni şifreniz','Hesabınız için yeni şifre',
  '<h2>Yeni Şifreniz</h2><p>Merhaba {{name}},</p><p>Yeni şifreniz: <b>{{password}}</b></p><p>İlk girişte değiştirmenizi öneririz.</p>',
  '["name","password"]'::jsonb, true),
('seo_report_ready','SEO raporunuz hazır','{{report_title}} hazır',
  '<h2>{{report_title}}</h2><p>Merhaba {{name}},</p><p>SEO raporunuz oluşturuldu. <a href="{{report_url}}">Görüntüleyin</a>.</p>',
  '["name","report_title","report_url"]'::jsonb, true)
ON CONFLICT (key) DO NOTHING;

-- Email send log
CREATE TABLE public.email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_key text,
  recipient text NOT NULL,
  subject text,
  status text NOT NULL DEFAULT 'sent',
  error text,
  sent_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.email_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY elog_super_select ON public.email_logs FOR SELECT TO authenticated
  USING (is_super_admin(auth.uid()));
CREATE POLICY elog_auth_insert ON public.email_logs FOR INSERT TO authenticated
  WITH CHECK (true);

-- Report templates (drag-drop blocks)
CREATE TABLE public.report_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  blocks jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_default boolean NOT NULL DEFAULT false,
  created_by uuid,
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.report_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY rtpl_admin_all ON public.report_templates FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY rtpl_client_select ON public.report_templates FOR SELECT TO authenticated
  USING (true);

INSERT INTO public.report_templates(name, description, blocks, is_default) VALUES
('Standart SEO Raporu','Varsayılan dönem raporu şablonu',
 '[
   {"id":"b1","type":"heading","props":{"text":"SEO Performans Raporu","level":1}},
   {"id":"b2","type":"summary","props":{"text":"Bu dönemde sitenin organik performansı..."}},
   {"id":"b3","type":"gsc_overview","props":{"title":"Search Console Özeti"}},
   {"id":"b4","type":"ga4_overview","props":{"title":"Analytics Özeti"}},
   {"id":"b5","type":"top_keywords","props":{"title":"En İyi Anahtar Kelimeler","limit":10}},
   {"id":"b6","type":"top_pages","props":{"title":"En İyi Sayfalar","limit":10}},
   {"id":"b7","type":"serp_rankings","props":{"title":"SERP Sıralamaları"}},
   {"id":"b8","type":"insights","props":{"title":"Öneriler ve Çıkarımlar"}}
 ]'::jsonb, true)
ON CONFLICT DO NOTHING;

-- Extend seo_reports
ALTER TABLE public.seo_reports
  ADD COLUMN IF NOT EXISTS template_id uuid,
  ADD COLUMN IF NOT EXISTS pdf_url text;
