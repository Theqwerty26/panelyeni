
-- SEO settings (singleton)
CREATE TABLE public.seo_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton boolean NOT NULL DEFAULT true UNIQUE,
  -- Search Console / GA4 share Google OAuth credentials
  google_client_id text,
  google_client_secret text,
  google_refresh_token text,
  gsc_enabled boolean NOT NULL DEFAULT false,
  ga4_enabled boolean NOT NULL DEFAULT false,
  last_tested_at timestamptz,
  last_test_status text,
  last_test_message text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);
ALTER TABLE public.seo_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY seo_settings_super_admin_all ON public.seo_settings FOR ALL TO authenticated
  USING (is_super_admin(auth.uid())) WITH CHECK (is_super_admin(auth.uid()));

-- Per-client SEO property mapping
CREATE TABLE public.client_seo_properties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  gsc_site_url text,
  ga4_property_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(client_id)
);
ALTER TABLE public.client_seo_properties ENABLE ROW LEVEL SECURITY;
CREATE POLICY csp_admin_all ON public.client_seo_properties FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY csp_client_select ON public.client_seo_properties FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = client_seo_properties.client_id AND c.user_id = auth.uid()));

-- Search Console metrics
CREATE TABLE public.gsc_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  date date NOT NULL,
  query text,
  page text,
  country text,
  device text,
  clicks integer NOT NULL DEFAULT 0,
  impressions integer NOT NULL DEFAULT 0,
  ctr numeric NOT NULL DEFAULT 0,
  position numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_gsc_metrics_client_date ON public.gsc_metrics(client_id, date DESC);
ALTER TABLE public.gsc_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY gsc_admin_all ON public.gsc_metrics FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY gsc_client_select ON public.gsc_metrics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = gsc_metrics.client_id AND c.user_id = auth.uid()));

-- GA4 metrics
CREATE TABLE public.ga4_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  date date NOT NULL,
  channel text,
  source_medium text,
  landing_page text,
  country text,
  device text,
  sessions integer NOT NULL DEFAULT 0,
  active_users integer NOT NULL DEFAULT 0,
  new_users integer NOT NULL DEFAULT 0,
  engaged_sessions integer NOT NULL DEFAULT 0,
  conversions integer NOT NULL DEFAULT 0,
  total_revenue numeric NOT NULL DEFAULT 0,
  bounce_rate numeric NOT NULL DEFAULT 0,
  avg_session_duration numeric NOT NULL DEFAULT 0,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_ga4_metrics_client_date ON public.ga4_metrics(client_id, date DESC);
ALTER TABLE public.ga4_metrics ENABLE ROW LEVEL SECURITY;
CREATE POLICY ga4_admin_all ON public.ga4_metrics FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY ga4_client_select ON public.ga4_metrics FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = ga4_metrics.client_id AND c.user_id = auth.uid()));

-- SEO reports
CREATE TABLE public.seo_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL,
  title text NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  summary text,
  data jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL DEFAULT 'draft',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.seo_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY seo_reports_admin_all ON public.seo_reports FOR ALL TO authenticated
  USING (is_admin_or_super(auth.uid())) WITH CHECK (is_admin_or_super(auth.uid()));
CREATE POLICY seo_reports_client_select ON public.seo_reports FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM clients c WHERE c.id = seo_reports.client_id AND c.user_id = auth.uid()));

-- Updated-at triggers
CREATE TRIGGER trg_seo_settings_updated BEFORE UPDATE ON public.seo_settings
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_csp_updated BEFORE UPDATE ON public.client_seo_properties
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER trg_seo_reports_updated BEFORE UPDATE ON public.seo_reports
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Seed singleton row
INSERT INTO public.seo_settings (singleton) VALUES (true) ON CONFLICT DO NOTHING;
