
create type public.app_role as enum ('admin','client');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null default 'client',
  created_at timestamptz not null default now(),
  unique(user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists(select 1 from public.user_roles where user_id=_user_id and role=_role)
$$;

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null unique,
  google_ads_customer_id text,
  user_id uuid references auth.users(id) on delete set null,
  last_synced_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.clients enable row level security;

create table public.ad_metrics (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.clients(id) on delete cascade,
  campaign_name text not null,
  date date not null,
  impressions int not null default 0,
  clicks int not null default 0,
  cost numeric(10,2) not null default 0,
  conversions int not null default 0,
  created_at timestamptz not null default now()
);
alter table public.ad_metrics enable row level security;
create index ad_metrics_client_date_idx on public.ad_metrics(client_id, date);

-- RLS
create policy "user_roles_self_or_admin_select" on public.user_roles
  for select to authenticated using (auth.uid()=user_id or public.has_role(auth.uid(),'admin'));
create policy "user_roles_admin_manage" on public.user_roles
  for all to authenticated using (public.has_role(auth.uid(),'admin'))
  with check (public.has_role(auth.uid(),'admin'));

create policy "clients_admin_all" on public.clients
  for all to authenticated using (public.has_role(auth.uid(),'admin'))
  with check (public.has_role(auth.uid(),'admin'));
create policy "clients_self_select" on public.clients
  for select to authenticated using (user_id = auth.uid());

create policy "metrics_admin_all" on public.ad_metrics
  for all to authenticated using (public.has_role(auth.uid(),'admin'))
  with check (public.has_role(auth.uid(),'admin'));
create policy "metrics_client_select_own" on public.ad_metrics
  for select to authenticated using (
    exists(select 1 from public.clients c where c.id = ad_metrics.client_id and c.user_id = auth.uid())
  );

-- Trigger: handle new auth user
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare user_count int;
begin
  select count(*) into user_count from auth.users;
  if user_count <= 1 then
    insert into public.user_roles(user_id, role) values (new.id, 'admin')
      on conflict do nothing;
  else
    insert into public.user_roles(user_id, role) values (new.id, 'client')
      on conflict do nothing;
    update public.clients set user_id = new.id where email = new.email;
  end if;
  return new;
end; $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Seed mock metrics on client creation
create or replace function public.seed_mock_metrics()
returns trigger language plpgsql security definer set search_path = public as $$
declare
  d date;
  campaigns text[] := array['Brand Search','Generic Keywords','Display Remarketing','Performance Max','YouTube Awareness'];
  c text;
begin
  for d in select generate_series(current_date - 29, current_date, '1 day'::interval)::date loop
    foreach c in array campaigns loop
      insert into public.ad_metrics(client_id, campaign_name, date, impressions, clicks, cost, conversions)
      values (
        new.id, c, d,
        (random()*5000+500)::int,
        (random()*200+10)::int,
        round((random()*300+20)::numeric, 2),
        (random()*15)::int
      );
    end loop;
  end loop;
  return new;
end; $$;

create trigger on_client_created
  after insert on public.clients
  for each row execute function public.seed_mock_metrics();
