// Deno edge function that sends email via classic SMTP using denomailer.
// Requires the caller to be authenticated as super_admin (verified via JWT + RPC).
import { SMTPClient } from "https://deno.land/x/denomailer@1.6.0/mod.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface SendInput {
  to: string | string[];
  subject: string;
  html?: string;
  text?: string;
  // optional override of stored settings
  overrideHost?: string;
  overridePort?: number;
  overrideUser?: string;
  overridePass?: string;
  overrideFrom?: string;
  overrideFromName?: string;
  overrideSecure?: boolean;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers: cors });

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!token) return json({ error: "Unauthorized" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const publishable = Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!;
    const admin = createClient(supabaseUrl, serviceKey);

    let userId: string | null = null;
    if (token === serviceKey) {
      // server-to-server call from TanStack server function; trust caller
      userId = null;
    } else {
      const userClient = createClient(supabaseUrl, publishable, {
        global: { headers: { Authorization: authHeader } },
      });
      const { data: userData, error: userErr } = await userClient.auth.getUser();
      if (userErr || !userData?.user) return json({ error: "Unauthorized" }, 401);
      userId = userData.user.id;
      const { data: role } = await admin
        .from("user_roles").select("role")
        .eq("user_id", userId).in("role", ["admin", "super_admin"]).maybeSingle();
      if (!role) return json({ error: "Forbidden" }, 403);
    }

    const body = (await req.json()) as SendInput;
    if (!body?.to || !body?.subject || (!body.html && !body.text)) {
      return json({ error: "Missing required fields (to, subject, html|text)" }, 400);
    }

    const { data: s, error: sErr } = await admin
      .from("smtp_settings")
      .select("*")
      .eq("singleton", true)
      .maybeSingle();
    if (sErr) return json({ error: sErr.message }, 500);

    const host = body.overrideHost ?? s?.host;
    const port = body.overridePort ?? s?.port ?? 587;
    const username = body.overrideUser ?? s?.username;
    const password = body.overridePass ?? s?.password;
    const fromEmail = body.overrideFrom ?? s?.from_email;
    const fromName = body.overrideFromName ?? s?.from_name ?? "";
    const secure = body.overrideSecure ?? s?.secure ?? false;

    if (!host || !username || !password || !fromEmail) {
      return json({ error: "SMTP not fully configured" }, 400);
    }
    if (!body.overrideHost && s?.enabled === false) {
      return json({ error: "SMTP is disabled" }, 400);
    }

    const client = new SMTPClient({
      connection: { hostname: host, port, tls: secure, auth: { username, password } },
    });

    try {
      await client.send({
        from: fromName ? `${fromName} <${fromEmail}>` : fromEmail,
        to: Array.isArray(body.to) ? body.to : [body.to],
        subject: body.subject,
        content: body.text ?? "",
        html: body.html ?? body.text ?? "",
      });
    } finally {
      try { await client.close(); } catch { /* ignore */ }
    }

    // log
    const toArr = Array.isArray(body.to) ? body.to : [body.to];
    for (const r of toArr) {
      await admin.from("email_logs").insert({
        recipient: r,
        subject: body.subject,
        status: "sent",
        sent_by: userId,
      });
    }

    return json({ ok: true });
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    return json({ error: message }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...cors },
  });
}