import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "super_admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: super admin only");
}

const KeySchema = z.enum(["general", "branding", "security"]);

export const getAppSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ key: KeySchema }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase
      .from("app_settings")
      .select("value")
      .eq("key", data.key)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { value: (row?.value ?? {}) as Record<string, string | number | boolean | null> };
  });

const SaveSchema = z.object({
  key: KeySchema,
  value: z.record(z.string(), z.unknown()),
});

export const saveAppSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => SaveSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin
      .from("app_settings")
      .upsert(
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        { key: data.key, value: data.value as any, updated_by: userId, updated_at: new Date().toISOString() },
        { onConflict: "key" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// AI providers
export const listAiProviders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("ai_provider_settings")
      .select("id, provider, enabled, model, base_url, max_tokens, temperature, system_prompt, is_default, api_key, updated_at")
      .order("provider");
    if (error) throw new Error(error.message);
    return {
      providers: (data ?? []).map((p) => ({
        ...p,
        api_key: p.api_key ? "••••••••" : null,
      })),
    };
  });

const UpsertProvider = z.object({
  provider: z.enum(["openai", "claude", "gemini", "deepseek"]),
  enabled: z.boolean(),
  is_default: z.boolean(),
  model: z.string().trim().max(100).optional().nullable(),
  base_url: z.string().trim().max(300).optional().nullable(),
  max_tokens: z.number().int().min(1).max(32000).optional().nullable(),
  temperature: z.number().min(0).max(2).optional().nullable(),
  system_prompt: z.string().max(4000).optional().nullable(),
  api_key: z.string().trim().max(500).optional().nullable(),
});

export const upsertAiProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => UpsertProvider.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: existing } = await supabaseAdmin
      .from("ai_provider_settings")
      .select("id, api_key")
      .eq("provider", data.provider)
      .maybeSingle();

    const patch: Record<string, unknown> = {
      provider: data.provider,
      enabled: data.enabled,
      is_default: data.is_default,
      model: data.model ?? null,
      base_url: data.base_url ?? null,
      max_tokens: data.max_tokens ?? null,
      temperature: data.temperature ?? null,
      system_prompt: data.system_prompt ?? null,
      updated_at: new Date().toISOString(),
    };
    // only set api_key if provided (and not the masked placeholder)
    if (data.api_key && !data.api_key.includes("••")) {
      patch.api_key = data.api_key;
    }

    if (data.is_default) {
      await supabaseAdmin
        .from("ai_provider_settings")
        .update({ is_default: false })
        .neq("provider", data.provider);
    }

    if (existing) {
      const { error } = await supabaseAdmin
        .from("ai_provider_settings")
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .update(patch as any)
        .eq("id", existing.id);
      if (error) throw new Error(error.message);
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { error } = await supabaseAdmin.from("ai_provider_settings").insert(patch as any);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

// Audit logs
export const listAuditLogs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("audit_logs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return { logs: data ?? [] };
  });