import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "super_admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: super admin only");
}

const MASK = "••••••••";

export const getSeoSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabaseAdmin
      .from("seo_settings")
      .select("*")
      .eq("singleton", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return {
      settings: data
        ? {
            ...data,
            google_client_secret: data.google_client_secret ? MASK : null,
            google_refresh_token: data.google_refresh_token ? MASK : null,
          }
        : null,
    };
  });

const SaveSchema = z.object({
  google_client_id: z.string().trim().max(300).nullable().optional(),
  google_client_secret: z.string().trim().max(500).nullable().optional(),
  google_refresh_token: z.string().trim().max(2000).nullable().optional(),
  gsc_enabled: z.boolean(),
  ga4_enabled: z.boolean(),
});

export const saveSeoSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => SaveSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const patch: Record<string, unknown> = {
      gsc_enabled: data.gsc_enabled,
      ga4_enabled: data.ga4_enabled,
      google_client_id: data.google_client_id ?? null,
      updated_at: new Date().toISOString(),
      updated_by: userId,
    };
    if (data.google_client_secret && !data.google_client_secret.includes("••")) {
      patch.google_client_secret = data.google_client_secret;
    }
    if (data.google_refresh_token && !data.google_refresh_token.includes("••")) {
      patch.google_refresh_token = data.google_refresh_token;
    }

    const { error } = await supabaseAdmin
      .from("seo_settings")
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .update(patch as any)
      .eq("singleton", true);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const testSeoConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: s, error } = await supabaseAdmin
      .from("seo_settings")
      .select("*")
      .eq("singleton", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!s?.google_client_id || !s?.google_client_secret || !s?.google_refresh_token) {
      const msg = "Missing Google OAuth credentials";
      await supabaseAdmin
        .from("seo_settings")
        .update({
          last_tested_at: new Date().toISOString(),
          last_test_status: "error",
          last_test_message: msg,
        })
        .eq("singleton", true);
      return { ok: false, message: msg };
    }

    try {
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: s.google_client_id,
          client_secret: s.google_client_secret,
          refresh_token: s.google_refresh_token,
          grant_type: "refresh_token",
        }),
      });
      const tokenJson = (await tokenRes.json()) as { access_token?: string; error?: string; error_description?: string };
      if (!tokenRes.ok || !tokenJson.access_token) {
        const msg = `OAuth failed: ${tokenJson.error_description || tokenJson.error || tokenRes.status}`;
        await supabaseAdmin
          .from("seo_settings")
          .update({ last_tested_at: new Date().toISOString(), last_test_status: "error", last_test_message: msg })
          .eq("singleton", true);
        return { ok: false, message: msg };
      }

      const checks: string[] = [];
      if (s.gsc_enabled) {
        const gscRes = await fetch("https://searchconsole.googleapis.com/webmasters/v3/sites", {
          headers: { Authorization: `Bearer ${tokenJson.access_token}` },
        });
        if (!gscRes.ok) {
          const msg = `Search Console error: ${gscRes.status}`;
          await supabaseAdmin
            .from("seo_settings")
            .update({ last_tested_at: new Date().toISOString(), last_test_status: "error", last_test_message: msg })
            .eq("singleton", true);
          return { ok: false, message: msg };
        }
        const sites = (await gscRes.json()) as { siteEntry?: unknown[] };
        checks.push(`GSC: ${sites.siteEntry?.length ?? 0} site(s)`);
      }
      if (s.ga4_enabled) {
        const gaRes = await fetch("https://analyticsadmin.googleapis.com/v1beta/accountSummaries", {
          headers: { Authorization: `Bearer ${tokenJson.access_token}` },
        });
        if (!gaRes.ok) {
          const msg = `GA4 error: ${gaRes.status}`;
          await supabaseAdmin
            .from("seo_settings")
            .update({ last_tested_at: new Date().toISOString(), last_test_status: "error", last_test_message: msg })
            .eq("singleton", true);
          return { ok: false, message: msg };
        }
        const acc = (await gaRes.json()) as { accountSummaries?: unknown[] };
        checks.push(`GA4: ${acc.accountSummaries?.length ?? 0} account(s)`);
      }
      const message = checks.length ? checks.join(" · ") : "Credentials valid (no service enabled)";
      await supabaseAdmin
        .from("seo_settings")
        .update({ last_tested_at: new Date().toISOString(), last_test_status: "success", last_test_message: message })
        .eq("singleton", true);
      return { ok: true, message };
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Unknown error";
      await supabaseAdmin
        .from("seo_settings")
        .update({ last_tested_at: new Date().toISOString(), last_test_status: "error", last_test_message: msg })
        .eq("singleton", true);
      return { ok: false, message: msg };
    }
  });

// SEO reports list/create
export const listSeoReports = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ clientId: z.string().uuid().optional() }).parse(i ?? {}))
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let q = supabase.from("seo_reports").select("*").order("created_at", { ascending: false }).limit(100);
    if (data.clientId) q = q.eq("client_id", data.clientId);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { reports: rows ?? [] };
  });

const CreateReport = z.object({
  client_id: z.string().uuid(),
  title: z.string().trim().min(1).max(200),
  period_start: z.string(),
  period_end: z.string(),
  summary: z.string().max(4000).optional().nullable(),
});

export const createSeoReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => CreateReport.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    // RLS will block clients
    const { data: row, error } = await supabase
      .from("seo_reports")
      .insert({ ...data, created_by: userId })
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return { report: row };
  });