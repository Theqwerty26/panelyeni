import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertAdminOrSuper(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .in("role", ["admin", "super_admin"])
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: admin access required");
}
// ── Types ───────────────────────────────────────────────
export type ContactStatus = "lead" | "prospect" | "customer" | "churned";
export type DealStage = "new" | "contacted" | "proposal" | "negotiation" | "won" | "lost";
export type ActivityType = "note" | "call" | "email" | "meeting" | "task";

export interface CrmContact {
  id: string;
  client_id: string | null;
  first_name: string;
  last_name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  job_title: string | null;
  status: ContactStatus;
  source: string | null;
  notes: string | null;
  tags: string[];
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
}

export interface CrmDeal {
  id: string;
  client_id: string | null;
  contact_id: string | null;
  title: string;
  value: number;
  currency: string;
  stage: DealStage;
  probability: number;
  close_date: string | null;
  notes: string | null;
  assigned_to: string | null;
  created_at: string;
  updated_at: string;
  contact?: Pick<CrmContact, "first_name" | "last_name" | "email">;
}

export interface CrmActivity {
  id: string;
  contact_id: string;
  deal_id: string | null;
  type: ActivityType;
  title: string;
  description: string | null;
  status: string;
  due_at: string | null;
  done_at: string | null;
  created_at: string;
}

// ── Contacts ────────────────────────────────────────────
export const listContacts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((d: { clientId?: string; status?: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    let q = supabase
      .from("crm_contacts")
      .select("*")
      .order("created_at", { ascending: false });
    if (data?.clientId) q = q.eq("client_id", data.clientId);
    if (data?.status) q = q.eq("status", data.status);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { contacts: (rows ?? []) as CrmContact[] };
  });

export const upsertContact = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: Partial<CrmContact> & { id?: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    if (data.id) {
      const { id, ...rest } = data;
      const { error } = await supabase.from("crm_contacts").update(rest).eq("id", id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabase.from("crm_contacts").insert({ ...data, created_by: userId });
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const deleteContact = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { id: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    const { error } = await supabase.from("crm_contacts").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ── Deals ───────────────────────────────────────────────
export const listDeals = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((d: { clientId?: string; stage?: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    let q = supabase
      .from("crm_deals")
      .select("*, contact:crm_contacts(first_name, last_name, email)")
      .order("created_at", { ascending: false });
    if (data?.clientId) q = q.eq("client_id", data.clientId);
    if (data?.stage) q = q.eq("stage", data.stage);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { deals: (rows ?? []) as CrmDeal[] };
  });

export const upsertDeal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: Partial<CrmDeal> & { id?: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    if (data.id) {
      const { id, contact, ...rest } = data as any;
      const { error } = await supabase.from("crm_deals").update(rest).eq("id", id);
      if (error) throw new Error(error.message);
    } else {
      const { contact, ...rest } = data as any;
      const { error } = await supabase.from("crm_deals").insert({ ...rest, created_by: userId });
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const deleteDeal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: { id: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    const { error } = await supabase.from("crm_deals").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ── Activities ──────────────────────────────────────────
export const listActivities = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .validator((d: { contactId: string }) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    const { data: rows, error } = await supabase
      .from("crm_activities")
      .select("*")
      .eq("contact_id", data.contactId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { activities: (rows ?? []) as CrmActivity[] };
  });

export const addActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .validator((d: Omit<CrmActivity, "id" | "created_at">) => d)
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    await assertAdminOrSuper(supabase, userId);
    const { error } = await supabase.from("crm_activities").insert({ ...data, created_by: userId });
    if (error) throw new Error(error.message);
    return { ok: true };
  });
