import type { Tables } from "@/integrations/supabase/types";

export type Metric = Tables<"ad_metrics">;

export function aggregateMetrics(rows: Metric[]) {
  const totals = rows.reduce(
    (acc, r) => {
      acc.cost += Number(r.cost);
      acc.clicks += r.clicks;
      acc.impressions += r.impressions;
      acc.conversions += r.conversions;
      return acc;
    },
    { cost: 0, clicks: 0, impressions: 0, conversions: 0 }
  );
  const ctr = totals.impressions ? (totals.clicks / totals.impressions) * 100 : 0;
  const cpc = totals.clicks ? totals.cost / totals.clicks : 0;
  return { ...totals, ctr, cpc };
}

export function groupByDate(rows: Metric[]) {
  const map = new Map<string, { date: string; cost: number; clicks: number; conversions: number }>();
  for (const r of rows) {
    const cur = map.get(r.date) ?? { date: r.date, cost: 0, clicks: 0, conversions: 0 };
    cur.cost += Number(r.cost);
    cur.clicks += r.clicks;
    cur.conversions += r.conversions;
    map.set(r.date, cur);
  }
  return Array.from(map.values()).sort((a, b) => a.date.localeCompare(b.date));
}

export function groupByCampaign(rows: Metric[]) {
  const map = new Map<string, { name: string; cost: number; clicks: number; impressions: number; conversions: number }>();
  for (const r of rows) {
    const cur = map.get(r.campaign_name) ?? {
      name: r.campaign_name,
      cost: 0,
      clicks: 0,
      impressions: 0,
      conversions: 0,
    };
    cur.cost += Number(r.cost);
    cur.clicks += r.clicks;
    cur.impressions += r.impressions;
    cur.conversions += r.conversions;
    map.set(r.campaign_name, cur);
  }
  return Array.from(map.values());
}