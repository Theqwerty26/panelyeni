import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "super_admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: super admin only");
}

async function logAudit(
  actorId: string,
  actorEmail: string | undefined,
  action: string,
  details: Record<string, unknown>,
) {
  await supabaseAdmin.from("audit_logs").insert({
    user_id: actorId,
    user_email: actorEmail ?? null,
    role: "super_admin",
    action,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    details: details as any,
  });
}

export const listUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: authData, error: authErr } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (authErr) throw new Error(authErr.message);

    const ids = authData.users.map((u) => u.id);
    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role")
      .in("user_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const roleMap = new Map<string, string>();
    for (const r of roles ?? []) roleMap.set(r.user_id, r.role as string);

    const { data: clients } = await supabaseAdmin
      .from("clients")
      .select("id, name, user_id, assigned_admin_id");

    return {
      users: authData.users.map((u) => ({
        id: u.id,
        email: u.email ?? "",
        created_at: u.created_at,
        last_sign_in_at: u.last_sign_in_at ?? null,
        role: (roleMap.get(u.id) ?? "client") as "super_admin" | "admin" | "client",
      })),
      clients: clients ?? [],
    };
  });

const CreateSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(8).max(100),
  role: z.enum(["super_admin", "admin", "client"]),
});

export const createUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => CreateSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
    });
    if (error || !created.user) throw new Error(error?.message ?? "Create failed");

    // handle_new_user trigger may have already inserted a role; force the requested role
    await supabaseAdmin.from("user_roles").delete().eq("user_id", created.user.id);
    const { error: rErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: created.user.id, role: data.role });
    if (rErr) throw new Error(rErr.message);

    await logAudit(userId, claims.email as string | undefined, "user.create", {
      target_email: data.email,
      role: data.role,
    });
    return { id: created.user.id };
  });

const UpdateRoleSchema = z.object({
  user_id: z.string().uuid(),
  role: z.enum(["super_admin", "admin", "client"]),
});

export const updateUserRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => UpdateRoleSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertSuperAdmin(supabase, userId);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.user_id);
    const { error } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: data.user_id, role: data.role });
    if (error) throw new Error(error.message);
    await logAudit(userId, claims.email as string | undefined, "user.update_role", {
      target_id: data.user_id,
      role: data.role,
    });
    return { ok: true };
  });

const ResetSchema = z.object({
  user_id: z.string().uuid(),
  password: z.string().min(8).max(100),
});

export const resetUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => ResetSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.user_id, {
      password: data.password,
    });
    if (error) throw new Error(error.message);
    await logAudit(userId, claims.email as string | undefined, "user.reset_password", {
      target_id: data.user_id,
    });
    return { ok: true };
  });

const DeleteSchema = z.object({ user_id: z.string().uuid() });

export const deleteUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => DeleteSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertSuperAdmin(supabase, userId);
    if (data.user_id === userId) throw new Error("You cannot delete yourself");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.user_id);
    if (error) throw new Error(error.message);
    await logAudit(userId, claims.email as string | undefined, "user.delete", {
      target_id: data.user_id,
    });
    return { ok: true };
  });

const AssignSchema = z.object({
  client_id: z.string().uuid(),
  admin_id: z.string().uuid().nullable(),
});

export const assignClientToAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => AssignSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId, claims } = context;
    await assertSuperAdmin(supabase, userId);
    const { error } = await supabaseAdmin
      .from("clients")
      .update({ assigned_admin_id: data.admin_id })
      .eq("id", data.client_id);
    if (error) throw new Error(error.message);
    await logAudit(userId, claims.email as string | undefined, "client.assign_admin", {
      client_id: data.client_id,
      admin_id: data.admin_id,
    });
    return { ok: true };
  });