import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data } = await supabase
    .from("user_roles").select("role").eq("user_id", userId)
    .eq("role", "super_admin").maybeSingle();
  if (!data) throw new Error("Forbidden: super admin only");
}

function keyFor(provider: string): string | undefined {
  if (provider === "semrush") return process.env.SEMRUSH_API_KEY;
  if (provider === "ahrefs") return process.env.AHREFS_API_KEY;
  if (provider === "serpapi") return process.env.SERPAPI_KEY;
  return undefined;
}

export const listSeoProviders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { data, error } = await supabaseAdmin
      .from("seo_provider_settings").select("*").order("provider");
    if (error) throw new Error(error.message);
    return {
      providers: (data ?? []).map((p) => ({
        ...p,
        has_api_key: !!keyFor(p.provider),
      })),
    };
  });

const SaveSchema = z.object({
  provider: z.enum(["semrush", "ahrefs", "serpapi"]),
  enabled: z.boolean(),
  base_url: z.string().trim().max(300).nullable().optional(),
  default_database: z.string().trim().max(20).nullable().optional(),
  rate_limit_per_minute: z.number().int().min(1).max(600).optional(),
});

export const saveSeoProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => SaveSchema.parse(i))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { error } = await supabaseAdmin
      .from("seo_provider_settings")
      .update({
        enabled: data.enabled,
        base_url: data.base_url ?? null,
        default_database: data.default_database ?? null,
        rate_limit_per_minute: data.rate_limit_per_minute ?? 30,
        updated_at: new Date().toISOString(),
        updated_by: context.userId,
      })
      .eq("provider", data.provider);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const TestSchema = z.object({ provider: z.enum(["semrush", "ahrefs", "serpapi"]) });

export const testSeoProvider = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => TestSchema.parse(i))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const key = keyFor(data.provider);
    let ok = false;
    let message = "";
    try {
      if (!key) throw new Error(`${data.provider.toUpperCase()}_API_KEY not configured`);
      if (data.provider === "semrush") {
        const r = await fetch(
          `https://api.semrush.com/?type=domain_organic&key=${key}&display_limit=1&export_columns=Ph&domain=example.com&database=us`,
        );
        const text = await r.text();
        if (!r.ok || text.toLowerCase().includes("error")) throw new Error(text.slice(0, 200));
        ok = true; message = "SEMrush API erişimi doğrulandı.";
      } else if (data.provider === "ahrefs") {
        const r = await fetch("https://api.ahrefs.com/v3/subscription-info/limits-and-usage", {
          headers: { Authorization: `Bearer ${key}`, Accept: "application/json" },
        });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j?.error?.message ?? `HTTP ${r.status}`);
        ok = true; message = "Ahrefs API doğrulandı.";
      } else if (data.provider === "serpapi") {
        const r = await fetch(`https://serpapi.com/account.json?api_key=${key}`);
        const j = await r.json().catch(() => ({}));
        if (!r.ok || j?.error) throw new Error(j?.error ?? `HTTP ${r.status}`);
        ok = true; message = `SerpAPI doğrulandı (kalan: ${j.searches_left ?? "?"})`;
      }
    } catch (e) {
      ok = false;
      message = e instanceof Error ? e.message : String(e);
    }
    await supabaseAdmin.from("seo_provider_settings").update({
      last_tested_at: new Date().toISOString(),
      last_test_status: ok ? "success" : "error",
      last_test_message: message,
    }).eq("provider", data.provider);
    return { ok, message };
  });

const FetchSerpSchema = z.object({
  client_id: z.string().uuid(),
  keyword: z.string().trim().min(1).max(200),
  domain: z.string().trim().min(1).max(200),
  country: z.string().trim().max(8).default("tr"),
  language: z.string().trim().max(8).default("tr"),
  device: z.enum(["desktop", "mobile"]).default("desktop"),
  provider: z.enum(["serpapi"]).default("serpapi"),
});

export const fetchSerpRanking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => FetchSerpSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: role } = await supabase
      .from("user_roles").select("role").eq("user_id", userId)
      .in("role", ["admin", "super_admin"]).maybeSingle();
    if (!role) throw new Error("Forbidden");

    const key = keyFor(data.provider);
    if (!key) throw new Error("SERPAPI_KEY not configured");

    const url = new URL("https://serpapi.com/search.json");
    url.searchParams.set("q", data.keyword);
    url.searchParams.set("gl", data.country);
    url.searchParams.set("hl", data.language);
    url.searchParams.set("device", data.device);
    url.searchParams.set("api_key", key);
    const r = await fetch(url.toString());
    const j = await r.json().catch(() => ({}));
    if (!r.ok || j?.error) throw new Error(j?.error ?? `HTTP ${r.status}`);

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const organic: any[] = j.organic_results ?? [];
    const needle = data.domain.replace(/^https?:\/\//, "").replace(/^www\./, "").toLowerCase();
    const idx = organic.findIndex((res) => {
      const link: string = res?.link ?? "";
      return link.toLowerCase().includes(needle);
    });
    const position = idx >= 0 ? (organic[idx]?.position ?? idx + 1) : null;
    const matchedUrl = idx >= 0 ? organic[idx]?.link : null;

    // previous position lookup
    const { data: prev } = await supabaseAdmin
      .from("serp_results")
      .select("position")
      .eq("client_id", data.client_id)
      .eq("keyword", data.keyword)
      .eq("device", data.device)
      .eq("country", data.country)
      .order("fetched_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const insert = {
      client_id: data.client_id,
      keyword: data.keyword,
      country: data.country,
      language: data.language,
      device: data.device,
      search_engine: "google",
      position,
      previous_position: prev?.position ?? null,
      url: matchedUrl,
      provider: data.provider,
      raw: { found_index: idx, total_results: organic.length },
      fetched_at: new Date().toISOString(),
    };
    const { data: row, error } = await supabaseAdmin
      .from("serp_results").insert(insert).select("*").single();
    if (error) throw new Error(error.message);
    return { result: row };
  });

export const listSerpResults = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ clientId: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    let q = supabase
      .from("serp_results")
      .select("*")
      .eq("client_id", data.clientId)
      .order("fetched_at", { ascending: false })
      .limit(500);
    void userId;
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return { results: rows ?? [] };
  });