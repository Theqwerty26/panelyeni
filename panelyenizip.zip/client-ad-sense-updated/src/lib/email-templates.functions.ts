import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data } = await supabase
    .from("user_roles").select("role").eq("user_id", userId)
    .eq("role", "super_admin").maybeSingle();
  if (!data) throw new Error("Forbidden: super admin only");
}

export const listEmailTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { data, error } = await supabaseAdmin
      .from("email_templates").select("*").order("name");
    if (error) throw new Error(error.message);
    return { templates: data ?? [] };
  });

const UpsertSchema = z.object({
  id: z.string().uuid().optional(),
  key: z.string().trim().min(1).max(80).regex(/^[a-z0-9_-]+$/i),
  name: z.string().trim().min(1).max(120),
  subject: z.string().trim().min(1).max(200),
  html: z.string().max(20000),
  text: z.string().max(10000).optional(),
  variables: z.array(z.string()).optional(),
  enabled: z.boolean().optional(),
});

export const upsertEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => UpsertSchema.parse(i))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const payload = {
      key: data.key,
      name: data.name,
      subject: data.subject,
      html: data.html,
      text: data.text ?? "",
      variables: data.variables ?? [],
      enabled: data.enabled ?? true,
      updated_at: new Date().toISOString(),
      updated_by: context.userId,
    };
    if (data.id) {
      const { error } = await supabaseAdmin.from("email_templates")
        .update(payload).eq("id", data.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin.from("email_templates").insert(payload);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const deleteEmailTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { data: tpl } = await supabaseAdmin
      .from("email_templates").select("is_system").eq("id", data.id).maybeSingle();
    if (tpl?.is_system) throw new Error("Sistem şablonu silinemez");
    const { error } = await supabaseAdmin.from("email_templates").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listEmailLogs = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertSuperAdmin(context.supabase, context.userId);
    const { data, error } = await supabaseAdmin
      .from("email_logs").select("*").order("created_at", { ascending: false }).limit(100);
    if (error) throw new Error(error.message);
    return { logs: data ?? [] };
  });