import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertAdmin(supabase: any, userId: string) {
  const { data } = await supabase
    .from("user_roles").select("role").eq("user_id", userId)
    .in("role", ["admin", "super_admin"]).maybeSingle();
  if (!data) throw new Error("Forbidden");
}

export const listReportTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { data, error } = await supabaseAdmin
      .from("report_templates").select("*").order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return { templates: data ?? [] };
  });

const BlockSchema = z.object({
  id: z.string(),
  type: z.string(),
  props: z.record(z.string(), z.unknown()).default({}),
});
const UpsertSchema = z.object({
  id: z.string().uuid().optional(),
  name: z.string().trim().min(1).max(120),
  description: z.string().max(500).optional().nullable(),
  blocks: z.array(BlockSchema),
  is_default: z.boolean().optional(),
});

export const upsertReportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => UpsertSchema.parse(i))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const payload = {
      name: data.name,
      description: data.description ?? null,
      blocks: data.blocks,
      is_default: data.is_default ?? false,
      updated_at: new Date().toISOString(),
    };
    if (data.is_default) {
      await supabaseAdmin.from("report_templates").update({ is_default: false }).eq("is_default", true);
    }
    if (data.id) {
      const { error } = await supabaseAdmin
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        .from("report_templates").update(payload as any).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }
    const { data: row, error } = await supabaseAdmin
      .from("report_templates")
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .insert({ ...(payload as any), created_by: context.userId })
      .select("id").single();
    if (error) throw new Error(error.message);
    return { ok: true, id: row.id };
  });

export const deleteReportTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => z.object({ id: z.string().uuid() }).parse(i))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.supabase, context.userId);
    const { error } = await supabaseAdmin.from("report_templates").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });