import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "super_admin")
    .maybeSingle();
  if (!data) throw new Error("Forbidden: super admin only");
}

const MASK = "••••••••";

export const getSmtpSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabaseAdmin
      .from("smtp_settings").select("*").eq("singleton", true).maybeSingle();
    if (error) throw new Error(error.message);
    return {
      settings: data ? { ...data, password: data.password ? MASK : null } : null,
    };
  });

const SaveSchema = z.object({
  host: z.string().trim().max(200).nullable().optional(),
  port: z.number().int().min(1).max(65535).optional(),
  username: z.string().trim().max(200).nullable().optional(),
  password: z.string().trim().max(500).nullable().optional(),
  from_email: z.string().email().nullable().optional(),
  from_name: z.string().trim().max(120).nullable().optional(),
  secure: z.boolean().optional(),
  enabled: z.boolean().optional(),
});

export const saveSmtpSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => SaveSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const patch: Record<string, unknown> = {
      host: data.host ?? null,
      port: data.port ?? 587,
      username: data.username ?? null,
      from_email: data.from_email ?? null,
      from_name: data.from_name ?? null,
      secure: data.secure ?? false,
      enabled: data.enabled ?? false,
      updated_at: new Date().toISOString(),
      updated_by: userId,
    };
    if (data.password && !data.password.includes("••")) patch.password = data.password;
    const { error } = await supabaseAdmin
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .from("smtp_settings").update(patch as any).eq("singleton", true);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

const TestSchema = z.object({ to: z.string().email() });

export const sendTestEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => TestSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const SUPABASE_URL = process.env.SUPABASE_URL!;
    const request = await fetch(`${SUPABASE_URL}/functions/v1/smtp-send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
        // pass the user's token via x header? service role enough for our checks.
      },
      body: JSON.stringify({
        to: data.to,
        subject: "SMTP Test - Time SEO Ads Panel",
        html: "<p>Bu bir SMTP test e-postasıdır. Yapılandırmanız çalışıyor.</p>",
        text: "SMTP test başarılı.",
      }),
    });
    const json = await request.json().catch(() => ({}));
    const ok = request.ok && !json?.error;
    await supabaseAdmin.from("smtp_settings").update({
      last_tested_at: new Date().toISOString(),
      last_test_status: ok ? "success" : "error",
      last_test_message: ok ? "Test e-posta gönderildi" : (json?.error ?? `HTTP ${request.status}`),
    }).eq("singleton", true);
    if (!ok) throw new Error(json?.error ?? `Test failed (${request.status})`);
    return { ok: true };
  });

const SendTemplatedSchema = z.object({
  to: z.string().email(),
  templateKey: z.string().min(1),
  variables: z.record(z.string(), z.string()).optional(),
});

export const sendTemplatedEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((i) => SendTemplatedSchema.parse(i))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    // admin or super can send
    const { data: role } = await supabase
      .from("user_roles").select("role").eq("user_id", userId)
      .in("role", ["admin", "super_admin"]).maybeSingle();
    if (!role) throw new Error("Forbidden");

    const { data: tpl, error } = await supabaseAdmin
      .from("email_templates").select("*").eq("key", data.templateKey).maybeSingle();
    if (error) throw new Error(error.message);
    if (!tpl || !tpl.enabled) throw new Error("Template not found or disabled");

    const vars = data.variables ?? {};
    const render = (s: string) => s.replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, k) => vars[k] ?? "");
    const subject = render(tpl.subject);
    const html = render(tpl.html ?? "");
    const text = render(tpl.text ?? "");

    const SUPABASE_URL = process.env.SUPABASE_URL!;
    const resp = await fetch(`${SUPABASE_URL}/functions/v1/smtp-send`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
      },
      body: JSON.stringify({ to: data.to, subject, html, text }),
    });
    const j = await resp.json().catch(() => ({}));
    if (!resp.ok || j?.error) {
      await supabaseAdmin.from("email_logs").insert({
        recipient: data.to, subject, template_key: data.templateKey,
        status: "error", error: j?.error ?? `HTTP ${resp.status}`, sent_by: userId,
      });
      throw new Error(j?.error ?? `Send failed (${resp.status})`);
    }
    await supabaseAdmin.from("email_logs").insert({
      recipient: data.to, subject, template_key: data.templateKey, status: "sent", sent_by: userId,
    });
    return { ok: true };
  });