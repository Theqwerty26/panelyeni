import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import type { TablesUpdate } from "@/integrations/supabase/types";

const SettingsSchema = z.object({
  developer_token: z.string().trim().max(200).optional().nullable(),
  client_id: z.string().trim().max(300).optional().nullable(),
  client_secret: z.string().trim().max(300).optional().nullable(),
  refresh_token: z.string().trim().max(500).optional().nullable(),
  login_customer_id: z.string().trim().max(40).optional().nullable(),
  mcc_customer_id: z.string().trim().max(40).optional().nullable(),
  test_customer_id: z.string().trim().max(40).optional().nullable(),
  api_version: z.string().trim().max(10).optional().nullable(),
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function assertSuperAdmin(supabase: any, userId: string) {
  const { data, error } = await supabase
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "super_admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Forbidden: super admin only");
}

export const getGoogleAdsSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);
    const { data, error } = await supabase
      .from("google_ads_settings")
      .select("*")
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) return { settings: null };
    // Mask secrets in response
    return {
      settings: {
        ...data,
        client_secret: data.client_secret ? "••••••••" : null,
        refresh_token: data.refresh_token ? "••••••••" : null,
        developer_token: data.developer_token ? `${data.developer_token.slice(0, 4)}••••` : null,
      },
    };
  });

export const saveGoogleAdsSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => SettingsSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    // Build patch — only include fields that are non-empty so masked values don't overwrite stored secrets
    const patch: TablesUpdate<"google_ads_settings"> = { updated_by: userId };
    for (const [k, v] of Object.entries(data)) {
      if (v === undefined) continue;
      if (typeof v === "string" && (v === "" || v.includes("••"))) continue;
      (patch as Record<string, unknown>)[k] = v;
    }

    const { data: existing } = await supabaseAdmin
      .from("google_ads_settings")
      .select("id")
      .limit(1)
      .maybeSingle();

    if (existing) {
      const { error } = await supabaseAdmin
        .from("google_ads_settings")
        .update(patch)
        .eq("id", existing.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin.from("google_ads_settings").insert(patch);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const testGoogleAdsConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    await assertSuperAdmin(supabase, userId);

    const { data: row, error } = await supabaseAdmin
      .from("google_ads_settings")
      .select("*")
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) {
      return { ok: false, message: "No settings saved. Fill credentials and Save first." };
    }

    const required = ["developer_token", "client_id", "client_secret", "refresh_token"] as const;
    for (const k of required) {
      if (!row[k]) {
        const msg = `Missing required field: ${k}`;
        await supabaseAdmin
          .from("google_ads_settings")
          .update({
            last_tested_at: new Date().toISOString(),
            last_test_status: "error",
            last_test_message: msg,
            last_test_account_name: null,
          })
          .eq("id", row.id);
        return { ok: false, message: msg };
      }
    }

    const apiVersion = row.api_version || "v17";

    try {
      // 1) Refresh access token
      const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
          client_id: row.client_id!,
          client_secret: row.client_secret!,
          refresh_token: row.refresh_token!,
          grant_type: "refresh_token",
        }),
      });
      const tokenJson = (await tokenRes.json()) as {
        access_token?: string;
        error?: string;
        error_description?: string;
      };
      if (!tokenRes.ok || !tokenJson.access_token) {
        const msg = `OAuth refresh failed: ${tokenJson.error_description || tokenJson.error || tokenRes.statusText}`;
        await supabaseAdmin
          .from("google_ads_settings")
          .update({
            last_tested_at: new Date().toISOString(),
            last_test_status: "error",
            last_test_message: msg,
          })
          .eq("id", row.id);
        return { ok: false, message: msg };
      }

      // 2) List accessible customers
      const headers: Record<string, string> = {
        Authorization: `Bearer ${tokenJson.access_token}`,
        "developer-token": row.developer_token!,
        "Content-Type": "application/json",
      };
      if (row.login_customer_id) {
        headers["login-customer-id"] = row.login_customer_id.replace(/-/g, "");
      }
      const listRes = await fetch(
        `https://googleads.googleapis.com/${apiVersion}/customers:listAccessibleCustomers`,
        { method: "GET", headers },
      );
      const listText = await listRes.text();
      if (!listRes.ok) {
        const msg = `Google Ads API error (${listRes.status}): ${listText.slice(0, 500)}`;
        await supabaseAdmin
          .from("google_ads_settings")
          .update({
            last_tested_at: new Date().toISOString(),
            last_test_status: "error",
            last_test_message: msg,
          })
          .eq("id", row.id);
        return { ok: false, message: msg };
      }
      let resourceNames: string[] = [];
      try {
        const j = JSON.parse(listText) as { resourceNames?: string[] };
        resourceNames = j.resourceNames || [];
      } catch {
        // ignore
      }
      const accountIds = resourceNames.map((r) => r.replace("customers/", ""));
      const accountName = `${accountIds.length} accessible account${accountIds.length === 1 ? "" : "s"}`;

      await supabaseAdmin
        .from("google_ads_settings")
        .update({
          last_tested_at: new Date().toISOString(),
          last_test_status: "ok",
          last_test_message: `Connected. ${accountName}.`,
          last_test_account_name: accountName,
        })
        .eq("id", row.id);

      return { ok: true, message: `Connected. ${accountName}.`, accounts: accountIds };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      await supabaseAdmin
        .from("google_ads_settings")
        .update({
          last_tested_at: new Date().toISOString(),
          last_test_status: "error",
          last_test_message: msg,
        })
        .eq("id", row.id);
      return { ok: false, message: msg };
    }
  });