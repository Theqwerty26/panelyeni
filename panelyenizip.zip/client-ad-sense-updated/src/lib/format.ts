export const fmtCurrency = (n: number) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n);
export const fmtNumber = (n: number) => new Intl.NumberFormat("en-US").format(Math.round(n));
export const fmtPct = (n: number) => `${n.toFixed(2)}%`;