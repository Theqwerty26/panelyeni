import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { MetricsView } from "@/components/MetricsView";

export const Route = createFileRoute("/_authenticated/dashboard")({ component: ClientDashboard });

function ClientDashboard() {
  const { user } = useAuth();
  const { t } = useI18n();
  const { data: client, isLoading } = useQuery({
    queryKey: ["my-client", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="rounded-lg border border-dashed p-10 text-center">
        <h2 className="text-lg font-semibold">{t.appName as string}</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          No client account is linked to your email yet. Please contact your administrator.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t.nav.dashboard as string}</h1>
        <p className="text-sm text-muted-foreground">{client.name}</p>
      </div>
      <MetricsView clientId={client.id} />
    </div>
  );
}