import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getSeoSettings, saveSeoSettings, testSeoConnection } from "@/lib/seo.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/super-admin/settings/seo")({
  component: SeoSettingsPage,
});

function SeoSettingsPage() {
  const qc = useQueryClient();
  const get = useServerFn(getSeoSettings);
  const save = useServerFn(saveSeoSettings);
  const test = useServerFn(testSeoConnection);
  const { data, isLoading } = useQuery({ queryKey: ["seo-settings"], queryFn: () => get() });

  const [form, setForm] = useState({
    google_client_id: "",
    google_client_secret: "",
    google_refresh_token: "",
    gsc_enabled: false,
    ga4_enabled: false,
  });

  useEffect(() => {
    if (data?.settings) {
      setForm({
        google_client_id: data.settings.google_client_id ?? "",
        google_client_secret: data.settings.google_client_secret ?? "",
        google_refresh_token: data.settings.google_refresh_token ?? "",
        gsc_enabled: !!data.settings.gsc_enabled,
        ga4_enabled: !!data.settings.ga4_enabled,
      });
    }
  }, [data]);

  const saveMut = useMutation({
    mutationFn: () => save({ data: form }),
    onSuccess: () => {
      toast.success("SEO ayarları kaydedildi");
      qc.invalidateQueries({ queryKey: ["seo-settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const testMut = useMutation({
    mutationFn: () => test(),
    onSuccess: (r) => {
      if (r.ok) toast.success(r.message ?? "Bağlantı başarılı");
      else toast.error(r.message ?? "Bağlantı başarısız");
      qc.invalidateQueries({ queryKey: ["seo-settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <div className="text-sm text-muted-foreground">Yükleniyor…</div>;
  const status = data?.settings?.last_test_status;

  return (
    <div className="space-y-6">
      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-base">
            <span>Search Console & Google Analytics</span>
            {status === "success" && <Badge className="bg-emerald-500/15 text-emerald-400">Bağlı</Badge>}
            {status === "error" && <Badge variant="destructive">Hata</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Google Cloud Console'dan oluşturduğunuz OAuth client ID/secret ve bir refresh token girin. Aynı kimlik bilgileri Search Console ve GA4 için kullanılır. Gerekli scope'lar:
            <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">webmasters.readonly</code>
            <code className="mx-1 rounded bg-muted px-1 py-0.5 text-xs">analytics.readonly</code>
          </p>

          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-1">
              <Label>OAuth Client ID</Label>
              <Input
                value={form.google_client_id}
                onChange={(e) => setForm((f) => ({ ...f, google_client_id: e.target.value }))}
                placeholder="xxxxx.apps.googleusercontent.com"
              />
            </div>
            <div className="space-y-1">
              <Label>OAuth Client Secret</Label>
              <Input
                type="password"
                value={form.google_client_secret}
                onChange={(e) => setForm((f) => ({ ...f, google_client_secret: e.target.value }))}
                placeholder="GOCSPX-…"
              />
            </div>
            <div className="space-y-1 md:col-span-2">
              <Label>Refresh Token</Label>
              <Input
                type="password"
                value={form.google_refresh_token}
                onChange={(e) => setForm((f) => ({ ...f, google_refresh_token: e.target.value }))}
                placeholder="1//0g…"
              />
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2">
            <label className="flex items-center justify-between rounded-md border border-border/60 p-3">
              <div>
                <div className="text-sm font-medium">Search Console</div>
                <div className="text-xs text-muted-foreground">Sorgu, tıklama, gösterim, pozisyon</div>
              </div>
              <Switch
                checked={form.gsc_enabled}
                onCheckedChange={(v) => setForm((f) => ({ ...f, gsc_enabled: v }))}
              />
            </label>
            <label className="flex items-center justify-between rounded-md border border-border/60 p-3">
              <div>
                <div className="text-sm font-medium">Google Analytics 4</div>
                <div className="text-xs text-muted-foreground">Oturum, kullanıcı, dönüşüm, gelir</div>
              </div>
              <Switch
                checked={form.ga4_enabled}
                onCheckedChange={(v) => setForm((f) => ({ ...f, ga4_enabled: v }))}
              />
            </label>
          </div>

          {data?.settings?.last_test_message && (
            <div className="text-xs text-muted-foreground">
              Son test: {data.settings.last_test_message}
              {data.settings.last_tested_at && ` · ${new Date(data.settings.last_tested_at).toLocaleString()}`}
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
              {saveMut.isPending ? "Kaydediliyor…" : "Kaydet"}
            </Button>
            <Button variant="outline" onClick={() => testMut.mutate()} disabled={testMut.isPending}>
              {testMut.isPending ? "Test ediliyor…" : "Bağlantıyı Test Et"}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}