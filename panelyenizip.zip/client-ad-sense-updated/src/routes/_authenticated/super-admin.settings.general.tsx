import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getAppSettings, saveAppSettings } from "@/lib/app-settings.functions";

export const Route = createFileRoute("/_authenticated/super-admin/settings/general")({
  component: GeneralPage,
});

function GeneralPage() {
  const get = useServerFn(getAppSettings);
  const save = useServerFn(saveAppSettings);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["app-settings", "general"], queryFn: () => get({ data: { key: "general" } }) });
  const [v, setV] = useState({ app_name: "Time SEO Ads Panel", default_language: "tr", timezone: "Europe/Istanbul" });

  useEffect(() => {
    const x = q.data?.value as Record<string, string> | undefined;
    if (x) setV({
      app_name: x.app_name ?? "Time SEO Ads Panel",
      default_language: x.default_language ?? "tr",
      timezone: x.timezone ?? "Europe/Istanbul",
    });
  }, [q.data]);

  const m = useMutation({
    mutationFn: () => save({ data: { key: "general", value: v } }),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["app-settings", "general"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>General</CardTitle>
        <CardDescription>Platform-wide defaults.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>App name</Label>
          <Input value={v.app_name} onChange={(e) => setV({ ...v, app_name: e.target.value })} />
        </div>
        <div className="space-y-2">
          <Label>Default language</Label>
          <Select value={v.default_language} onValueChange={(x) => setV({ ...v, default_language: x })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="tr">Türkçe</SelectItem>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="sq">Shqip</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Timezone</Label>
          <Input value={v.timezone} onChange={(e) => setV({ ...v, timezone: e.target.value })} />
        </div>
        <Button onClick={() => m.mutate()} disabled={m.isPending}>
          {m.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
        </Button>
      </CardContent>
    </Card>
  );
}