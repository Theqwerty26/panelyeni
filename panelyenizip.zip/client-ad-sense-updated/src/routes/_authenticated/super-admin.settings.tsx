import { createFileRoute, Link, Navigate, Outlet, useRouterState } from "@tanstack/react-router";
import { useAuth } from "@/lib/auth-context";
import { cn } from "@/lib/utils";
import { Settings, Globe, Palette, Bot, ShieldCheck, Users, Search, Mail, Zap } from "lucide-react";

export const Route = createFileRoute("/_authenticated/super-admin/settings")({
  component: SettingsLayout,
});

const tabs = [
  { url: "/super-admin/settings/general", label: "General", icon: Globe },
  { url: "/super-admin/settings/branding", label: "Branding", icon: Palette },
  { url: "/super-admin/settings/google-ads", label: "Google Ads API", icon: Settings },
  { url: "/super-admin/settings/seo", label: "SEO / Analytics", icon: Search },
  { url: "/super-admin/settings/seo-providers", label: "SEO Providers", icon: Zap },
  { url: "/super-admin/settings/smtp", label: "SMTP", icon: Mail },
  { url: "/super-admin/settings/ai", label: "AI Providers", icon: Bot },
  { url: "/super-admin/settings/security", label: "Security", icon: ShieldCheck },
  { url: "/super-admin/settings/users", label: "Users", icon: Users },
];

function SettingsLayout() {
  const { role, loading } = useAuth();
  const path = useRouterState({ select: (r) => r.location.pathname });
  if (loading) return null;
  if (role !== "super_admin") return <Navigate to="/dashboard" />;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-muted-foreground">Configure your platform, integrations and providers.</p>
      </div>
      <nav className="flex flex-wrap gap-1 border-b border-border/60">
        {tabs.map((t) => {
          const active = path.startsWith(t.url);
          return (
            <Link
              key={t.url}
              to={t.url}
              className={cn(
                "inline-flex items-center gap-2 rounded-t-md px-3 py-2 text-sm transition-colors -mb-px border-b-2",
                active
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              <t.icon className="h-4 w-4" /> {t.label}
            </Link>
          );
        })}
      </nav>
      <Outlet />
    </div>
  );
}