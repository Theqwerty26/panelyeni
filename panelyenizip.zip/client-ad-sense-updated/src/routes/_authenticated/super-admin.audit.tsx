import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth-context";
import { listAuditLogs } from "@/lib/app-settings.functions";

export const Route = createFileRoute("/_authenticated/super-admin/audit")({
  component: AuditPage,
});

function AuditPage() {
  const { role, loading } = useAuth();
  const list = useServerFn(listAuditLogs);
  const q = useQuery({
    queryKey: ["audit-logs"],
    queryFn: () => list(),
    enabled: role === "super_admin",
  });
  if (loading) return null;
  if (role !== "super_admin") return <Navigate to="/dashboard" />;

  const logs = q.data?.logs ?? [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Audit log</h1>
        <p className="text-sm text-muted-foreground">Last 200 administrative events.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Events</CardTitle>
          <CardDescription>Most recent first.</CardDescription>
        </CardHeader>
        <CardContent>
          {logs.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No events yet.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Actor</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((l) => (
                  <TableRow key={l.id}>
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                      {format(new Date(l.created_at), "PPp")}
                    </TableCell>
                    <TableCell className="text-sm">
                      {l.user_email ?? "—"}{l.role && <Badge variant="secondary" className="ml-2">{l.role}</Badge>}
                    </TableCell>
                    <TableCell><code className="text-xs">{l.action}</code></TableCell>
                    <TableCell>
                      <pre className="text-[11px] text-muted-foreground whitespace-pre-wrap break-all max-w-md">
                        {JSON.stringify(l.details, null, 0)}
                      </pre>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}