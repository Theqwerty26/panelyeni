import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getSmtpSettings, saveSmtpSettings, sendTestEmail } from "@/lib/smtp.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Mail, Send, Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/super-admin/settings/smtp")({
  component: SmtpPage,
});

function SmtpPage() {
  const get = useServerFn(getSmtpSettings);
  const save = useServerFn(saveSmtpSettings);
  const test = useServerFn(sendTestEmail);
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["smtp"], queryFn: () => get() });
  const s = data?.settings;

  const [form, setForm] = useState({
    host: "", port: 587, username: "", password: "",
    from_email: "", from_name: "", secure: false, enabled: false,
  });
  const [testTo, setTestTo] = useState("");

  useEffect(() => {
    if (s) setForm({
      host: s.host ?? "", port: s.port ?? 587,
      username: s.username ?? "", password: s.password ?? "",
      from_email: s.from_email ?? "", from_name: s.from_name ?? "",
      secure: !!s.secure, enabled: !!s.enabled,
    });
  }, [s]);

  const saveMut = useMutation({
    mutationFn: () => save({ data: form }),
    onSuccess: () => { toast.success("SMTP ayarları kaydedildi"); qc.invalidateQueries({ queryKey: ["smtp"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const testMut = useMutation({
    mutationFn: () => test({ data: { to: testTo } }),
    onSuccess: () => { toast.success("Test e-posta gönderildi"); qc.invalidateQueries({ queryKey: ["smtp"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Mail className="h-5 w-5" /> SMTP Yapılandırması</CardTitle>
          <CardDescription>Klasik SMTP sunucunuzla şifre/rapor mailleri gönderin.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1"><Label>Host</Label>
              <Input value={form.host} onChange={e => setForm({ ...form, host: e.target.value })} placeholder="smtp.gmail.com" /></div>
            <div className="space-y-1"><Label>Port</Label>
              <Input type="number" value={form.port} onChange={e => setForm({ ...form, port: Number(e.target.value) })} /></div>
            <div className="space-y-1"><Label>Kullanıcı adı</Label>
              <Input value={form.username} onChange={e => setForm({ ...form, username: e.target.value })} /></div>
            <div className="space-y-1"><Label>Parola</Label>
              <Input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="••••••••" /></div>
            <div className="space-y-1"><Label>Gönderen e-posta</Label>
              <Input type="email" value={form.from_email} onChange={e => setForm({ ...form, from_email: e.target.value })} /></div>
            <div className="space-y-1"><Label>Gönderen adı</Label>
              <Input value={form.from_name} onChange={e => setForm({ ...form, from_name: e.target.value })} /></div>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2"><Switch checked={form.secure} onCheckedChange={v => setForm({ ...form, secure: v })} /><Label>SSL/TLS (465)</Label></div>
            <div className="flex items-center gap-2"><Switch checked={form.enabled} onCheckedChange={v => setForm({ ...form, enabled: v })} /><Label>Etkin</Label></div>
          </div>
          {s?.last_test_status && (
            <div className="flex items-center gap-2 text-sm">
              <Badge variant={s.last_test_status === "success" ? "default" : "destructive"}>{s.last_test_status}</Badge>
              <span className="text-muted-foreground">{s.last_test_message}</span>
            </div>
          )}
          <div className="flex gap-2 pt-2">
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
              {saveMut.isPending && <Loader2 className="mr-1 h-4 w-4 animate-spin" />} Kaydet
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Test e-posta gönder</CardTitle>
          <CardDescription>Yapılandırmayı kaydettikten sonra test edin.</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center gap-2">
          <Input type="email" placeholder="alici@ornek.com" value={testTo} onChange={e => setTestTo(e.target.value)} />
          <Button onClick={() => testMut.mutate()} disabled={!testTo || testMut.isPending}>
            {testMut.isPending ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Send className="mr-1 h-4 w-4" />} Test gönder
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}