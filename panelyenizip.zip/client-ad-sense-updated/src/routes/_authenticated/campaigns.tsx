import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { MetricsView } from "@/components/MetricsView";

export const Route = createFileRoute("/_authenticated/campaigns")({ component: CampaignsPage });

function CampaignsPage() {
  const { user } = useAuth();
  const { t } = useI18n();
  const { data: client } = useQuery({
    queryKey: ["my-client", user?.id],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("*").eq("user_id", user!.id).maybeSingle();
      return data;
    },
    enabled: !!user,
  });

  if (!client) {
    return <div className="text-sm text-muted-foreground">No client linked.</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t.nav.campaigns as string}</h1>
        <p className="text-sm text-muted-foreground">{client.name}</p>
      </div>
      <MetricsView clientId={client.id} showOnlyTable />
    </div>
  );
}