import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Loader2, Shield, Clock, Key, Eye, EyeOff } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { getAppSettings, saveAppSettings } from "@/lib/app-settings.functions";

export const Route = createFileRoute("/_authenticated/super-admin/settings/security")({
  component: SecurityPage,
});

function SecurityPage() {
  const qc = useQueryClient();
  const getSetting = useServerFn(getAppSettings);
  const saveSetting = useServerFn(saveAppSettings);

  const { data, isLoading } = useQuery({
    queryKey: ["app-settings", "security"],
    queryFn: () => getSetting({ data: { key: "security" } }),
  });

  const val = (data?.value ?? {}) as Record<string, any>;

  const [form, setForm] = useState<Record<string, any>>({});
  const merged = { ...{ session_timeout_hours: 24, max_login_attempts: 5, require_2fa: false, password_min_length: 8, audit_log_retention_days: 90 }, ...val, ...form };

  const saveM = useMutation({
    mutationFn: () => saveSetting({ data: { key: "security", value: merged } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["app-settings", "security"] });
      setForm({});
      toast.success("Güvenlik ayarları kaydedildi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;

  return (
    <div className="space-y-6 max-w-2xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Shield className="h-5 w-5" />Oturum Ayarları</CardTitle>
          <CardDescription>Kullanıcı oturum süresi ve giriş politikaları.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Clock className="h-4 w-4" />Oturum Süresi (saat)</Label>
              <Input
                type="number"
                min={1}
                max={720}
                value={merged.session_timeout_hours}
                onChange={e => setForm(f => ({ ...f, session_timeout_hours: parseInt(e.target.value) || 24 }))}
              />
              <p className="text-xs text-muted-foreground">Kullanıcı bu süre sonra otomatik çıkış yapar.</p>
            </div>
            <div className="space-y-2">
              <Label className="flex items-center gap-2"><Key className="h-4 w-4" />Maks. Giriş Denemesi</Label>
              <Input
                type="number"
                min={1}
                max={20}
                value={merged.max_login_attempts}
                onChange={e => setForm(f => ({ ...f, max_login_attempts: parseInt(e.target.value) || 5 }))}
              />
              <p className="text-xs text-muted-foreground">Bu sayıyı geçen denemeler kilitlenir.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Şifre Politikası</CardTitle>
          <CardDescription>Yeni şifreler için minimum gereksinimler.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 max-w-xs">
            <Label>Minimum Şifre Uzunluğu</Label>
            <Input
              type="number"
              min={6}
              max={64}
              value={merged.password_min_length}
              onChange={e => setForm(f => ({ ...f, password_min_length: parseInt(e.target.value) || 8 }))}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Audit Log</CardTitle>
          <CardDescription>Yönetim eylemlerinin saklanma süresi.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2 max-w-xs">
            <Label>Kayıt Saklama Süresi (gün)</Label>
            <Input
              type="number"
              min={7}
              max={3650}
              value={merged.audit_log_retention_days}
              onChange={e => setForm(f => ({ ...f, audit_log_retention_days: parseInt(e.target.value) || 90 }))}
            />
            <p className="text-xs text-muted-foreground">Bu süreden eski audit log kayıtları silinir.</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>
          {saveM.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
          Kaydet
        </Button>
      </div>
    </div>
  );
}
