import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/super-admin/settings/")({
  component: () => <Navigate to="/super-admin/settings/google-ads" />,
});