import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Users, BarChart3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MetricsView } from "@/components/MetricsView";
import { KpiCard } from "@/components/KpiCard";

export const Route = createFileRoute("/_authenticated/admin/dashboard")({ component: AdminDashboard });

function AdminDashboard() {
  const { role, loading } = useAuth();
  const { t } = useI18n();
  const [selected, setSelected] = useState<string>("");

  const { data: clients = [] } = useQuery({
    queryKey: ["admin-clients"],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("*").order("created_at", { ascending: false });
      return data ?? [];
    },
    enabled: role === "admin",
  });

  const { data: campaignCount = 0 } = useQuery({
    queryKey: ["campaign-count"],
    queryFn: async () => {
      const { count } = await supabase.from("ad_metrics").select("campaign_name", { count: "exact", head: true });
      return count ?? 0;
    },
    enabled: role === "admin",
  });

  if (loading) return null;
  if (role !== "admin" && role !== "super_admin") return <Navigate to="/dashboard" />;

  const activeClient = clients.find(c => c.id === selected) ?? clients[0];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{t.admin.title as string}</h1>
        <p className="text-sm text-muted-foreground">{t.admin.subtitle as string}</p>
      </div>

      <div className="grid gap-4 grid-cols-2 lg:grid-cols-4">
        <KpiCard label={t.admin.totalClients as string} value={clients.length} icon={Users} />
        <KpiCard label={t.admin.totalCampaigns as string} value={campaignCount} icon={BarChart3} accent="from-chart-2 to-primary" />
      </div>

      {clients.length === 0 ? (
        <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">{t.admin.noClients as string}</CardContent></Card>
      ) : (
        <>
          <Card className="border-border/60">
            <CardHeader><CardTitle className="text-base">{t.common.client as string}</CardTitle></CardHeader>
            <CardContent>
              <Select value={activeClient?.id} onValueChange={setSelected}>
                <SelectTrigger className="w-full md:w-[320px]"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {clients.map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.name} — {c.email}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>

          {activeClient && <MetricsView clientId={activeClient.id} clientLabel={activeClient.name} />}
        </>
      )}
    </div>
  );
}