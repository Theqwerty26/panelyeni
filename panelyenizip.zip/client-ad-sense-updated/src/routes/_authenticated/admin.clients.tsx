import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Pencil, Trash2, RefreshCw } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import type { Tables } from "@/integrations/supabase/types";

type Client = Tables<"clients">;

export const Route = createFileRoute("/_authenticated/admin/clients")({ component: AdminClients });

function AdminClients() {
  const { role, loading } = useAuth();
  const { t } = useI18n();
  const qc = useQueryClient();
  const [editing, setEditing] = useState<Client | null>(null);
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState<Client | null>(null);
  const [form, setForm] = useState({ name: "", email: "", google_ads_customer_id: "" });

  const { data: clients = [] } = useQuery({
    queryKey: ["admin-clients"],
    queryFn: async () => {
      const { data, error } = await supabase.from("clients").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: role === "admin",
  });

  const upsert = useMutation({
    mutationFn: async () => {
      if (editing) {
        const { error } = await supabase.from("clients").update(form).eq("id", editing.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("clients").insert(form);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-clients"] });
      setOpen(false);
      setEditing(null);
      toast.success(editing ? (t.admin.clientUpdated as string) : (t.admin.clientCreated as string));
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("clients").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-clients"] });
      setDeleting(null);
      toast.success(t.admin.clientDeleted as string);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const sync = useMutation({
    mutationFn: async () => {
      // Mock sync: bumps last_synced_at on every client
      const now = new Date().toISOString();
      const { error } = await supabase
        .from("clients")
        .update({ last_synced_at: now })
        .neq("id", "00000000-0000-0000-0000-000000000000");
      if (error) throw error;
      // Simulate latency
      await new Promise(r => setTimeout(r, 600));
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-clients"] });
      toast.success(t.admin.synced as string);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (loading) return null;
  if (role !== "admin" && role !== "super_admin") return <Navigate to="/dashboard" />;

  const openCreate = () => {
    setEditing(null);
    setForm({ name: "", email: "", google_ads_customer_id: "" });
    setOpen(true);
  };
  const openEdit = (c: Client) => {
    setEditing(c);
    setForm({ name: c.name, email: c.email, google_ads_customer_id: c.google_ads_customer_id ?? "" });
    setOpen(true);
  };

  const lastSync = clients.reduce<string | null>((acc, c) => {
    if (!c.last_synced_at) return acc;
    if (!acc || c.last_synced_at > acc) return c.last_synced_at;
    return acc;
  }, null);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{t.nav.clients as string}</h1>
          <p className="text-sm text-muted-foreground">
            {t.admin.lastSync as string}:{" "}
            <span className="font-medium text-foreground">
              {lastSync ? format(new Date(lastSync), "PPp") : (t.admin.never as string)}
            </span>
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => sync.mutate()} disabled={sync.isPending}>
            <RefreshCw className={`h-4 w-4 mr-2 ${sync.isPending ? "animate-spin" : ""}`} />
            {sync.isPending ? (t.admin.syncing as string) : (t.admin.syncData as string)}
          </Button>
          <Button onClick={openCreate}>
            <Plus className="h-4 w-4 mr-2" />
            {t.admin.addClient as string}
          </Button>
        </div>
      </div>

      <Card className="border-border/60">
        <CardHeader><CardTitle className="text-base">{t.nav.clients as string}</CardTitle></CardHeader>
        <CardContent>
          {clients.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">{t.admin.noClients as string}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t.admin.clientName as string}</TableHead>
                  <TableHead>{t.admin.clientEmail as string}</TableHead>
                  <TableHead>{t.admin.googleAdsId as string}</TableHead>
                  <TableHead>{t.admin.lastSync as string}</TableHead>
                  <TableHead className="text-right">{t.admin.actions as string}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map(c => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell className="text-muted-foreground">{c.email}</TableCell>
                    <TableCell><code className="text-xs">{c.google_ads_customer_id ?? "—"}</code></TableCell>
                    <TableCell className="text-muted-foreground text-xs">
                      {c.last_synced_at ? format(new Date(c.last_synced_at), "PPp") : (t.admin.never as string)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(c)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeleting(c)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? (t.admin.editClient as string) : (t.admin.addClient as string)}</DialogTitle>
          </DialogHeader>
          <form
            className="space-y-4"
            onSubmit={e => {
              e.preventDefault();
              upsert.mutate();
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="name">{t.admin.clientName as string}</Label>
              <Input id="name" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">{t.admin.clientEmail as string}</Label>
              <Input id="email" type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="gads">{t.admin.googleAdsId as string}</Label>
              <Input id="gads" placeholder="123-456-7890" value={form.google_ads_customer_id} onChange={e => setForm({ ...form, google_ads_customer_id: e.target.value })} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                {t.admin.cancel as string}
              </Button>
              <Button type="submit" disabled={upsert.isPending}>{t.admin.save as string}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t.admin.deleteClient as string}</AlertDialogTitle>
            <AlertDialogDescription>{t.admin.confirmDelete as string}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t.admin.cancel as string}</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleting && del.mutate(deleting.id)}>
              {t.admin.deleteClient as string}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}