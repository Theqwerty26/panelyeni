import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { toast } from "sonner";
import {
  listContacts, upsertContact, deleteContact,
  listDeals, upsertDeal, deleteDeal,
  addActivity, listActivities,
  type CrmContact, type CrmDeal, type CrmActivity,
  type ContactStatus, type DealStage, type ActivityType,
} from "@/lib/crm.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Users, TrendingUp, Plus, Pencil, Trash2,
  Phone, Mail, Building2, Star, MessageSquare,
  PhoneCall, Calendar, CheckSquare, Loader2,
} from "lucide-react";
import { format } from "date-fns";

export const Route = createFileRoute("/_authenticated/crm")({ component: CrmPage });

// ── Status / Stage helpers ──────────────────────────────
const contactStatusMap: Record<ContactStatus, { label: string; color: string }> = {
  lead:     { label: "Lead",      color: "bg-blue-100 text-blue-700" },
  prospect: { label: "Prospect",  color: "bg-yellow-100 text-yellow-700" },
  customer: { label: "Müşteri",   color: "bg-green-100 text-green-700" },
  churned:  { label: "Kayıp",     color: "bg-red-100 text-red-700" },
};

const dealStageMap: Record<DealStage, { label: string; color: string }> = {
  new:         { label: "Yeni",          color: "bg-slate-100 text-slate-700" },
  contacted:   { label: "İletişime geç", color: "bg-blue-100 text-blue-700" },
  proposal:    { label: "Teklif",        color: "bg-purple-100 text-purple-700" },
  negotiation: { label: "Müzakere",      color: "bg-orange-100 text-orange-700" },
  won:         { label: "Kazanıldı",     color: "bg-green-100 text-green-700" },
  lost:        { label: "Kaybedildi",    color: "bg-red-100 text-red-700" },
};

const activityIconMap: Record<ActivityType, React.ElementType> = {
  note:    MessageSquare,
  call:    PhoneCall,
  email:   Mail,
  meeting: Calendar,
  task:    CheckSquare,
};

function StatusBadge({ status }: { status: ContactStatus }) {
  const s = contactStatusMap[status];
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${s.color}`}>{s.label}</span>;
}

function StageBadge({ stage }: { stage: DealStage }) {
  const s = dealStageMap[stage];
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${s.color}`}>{s.label}</span>;
}

// ── Main page ───────────────────────────────────────────
function CrmPage() {
  const { role, loading } = useAuth();

  if (loading) return null;
  if (role !== "admin" && role !== "super_admin") return <Navigate to="/dashboard" />;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Users className="h-6 w-6" /> CRM
        </h1>
        <p className="text-sm text-muted-foreground">Müşteri ilişkileri ve satış süreçleri yönetimi</p>
      </div>
      <Tabs defaultValue="contacts">
        <TabsList>
          <TabsTrigger value="contacts"><Users className="h-4 w-4 mr-2" />Kişiler</TabsTrigger>
          <TabsTrigger value="deals"><TrendingUp className="h-4 w-4 mr-2" />Fırsatlar</TabsTrigger>
          <TabsTrigger value="pipeline"><Star className="h-4 w-4 mr-2" />Pipeline</TabsTrigger>
        </TabsList>
        <TabsContent value="contacts" className="mt-4"><ContactsTab /></TabsContent>
        <TabsContent value="deals" className="mt-4"><DealsTab /></TabsContent>
        <TabsContent value="pipeline" className="mt-4"><PipelineTab /></TabsContent>
      </Tabs>
    </div>
  );
}

// ── CONTACTS TAB ────────────────────────────────────────
function ContactsTab() {
  const qc = useQueryClient();
  const list   = useServerFn(listContacts);
  const upsert = useServerFn(upsertContact);
  const del    = useServerFn(deleteContact);
  const listAct = useServerFn(listActivities);
  const addAct  = useServerFn(addActivity);

  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState<CrmContact | null>(null);
  const [selectedContact, setSelectedContact] = useState<CrmContact | null>(null);
  const [editing, setEditing] = useState<CrmContact | null>(null);
  const [form, setForm] = useState<Partial<CrmContact>>({
    first_name: "", last_name: "", email: "", phone: "", company: "",
    job_title: "", status: "lead", notes: "",
  });
  const [actForm, setActForm] = useState({ type: "note" as ActivityType, title: "", description: "" });

  const { data: clientsData } = useQuery({
    queryKey: ["crm-clients"],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("id, name").order("name");
      return data ?? [];
    },
  });

  const { data, isLoading } = useQuery({
    queryKey: ["crm-contacts", filterStatus],
    queryFn: () => list({ data: filterStatus !== "all" ? { status: filterStatus } : {} }),
  });

  const { data: activitiesData } = useQuery({
    queryKey: ["crm-activities", selectedContact?.id],
    queryFn: () => listAct({ data: { contactId: selectedContact!.id } }),
    enabled: !!selectedContact,
  });

  const upsertM = useMutation({
    mutationFn: () => upsert({ data: editing ? { ...form, id: editing.id } : form }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["crm-contacts"] });
      setOpen(false); setEditing(null);
      setForm({ first_name: "", last_name: "", email: "", phone: "", company: "", job_title: "", status: "lead", notes: "" });
      toast.success(editing ? "Kişi güncellendi" : "Kişi eklendi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const delM = useMutation({
    mutationFn: () => del({ data: { id: deleting!.id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["crm-contacts"] });
      setDeleting(null);
      toast.success("Kişi silindi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const actM = useMutation({
    mutationFn: () => addAct({
      data: {
        contact_id: selectedContact!.id,
        client_id: selectedContact!.client_id,
        deal_id: null,
        status: "done",
        due_at: null,
        done_at: new Date().toISOString(),
        ...actForm,
      } as any,
    }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["crm-activities", selectedContact?.id] });
      setActForm({ type: "note", title: "", description: "" });
      toast.success("Aktivite eklendi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const contacts = useMemo(() => {
    const list = data?.contacts ?? [];
    if (!search) return list;
    const q = search.toLowerCase();
    return list.filter(c =>
      `${c.first_name} ${c.last_name} ${c.email} ${c.company}`.toLowerCase().includes(q)
    );
  }, [data, search]);

  const openCreate = () => {
    setEditing(null);
    setForm({ first_name: "", last_name: "", email: "", phone: "", company: "", job_title: "", status: "lead", notes: "" });
    setOpen(true);
  };
  const openEdit = (c: CrmContact) => {
    setEditing(c);
    setForm({ first_name: c.first_name, last_name: c.last_name, email: c.email ?? "", phone: c.phone ?? "", company: c.company ?? "", job_title: c.job_title ?? "", status: c.status, notes: c.notes ?? "", client_id: c.client_id ?? undefined });
    setOpen(true);
  };

  const activities = activitiesData?.activities ?? [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3 items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          <Input placeholder="Ara..." value={search} onChange={e => setSearch(e.target.value)} className="w-48" />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tümü</SelectItem>
              {Object.entries(contactStatusMap).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={openCreate}><Plus className="h-4 w-4 mr-2" />Kişi Ekle</Button>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-10 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : contacts.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Henüz kişi yok.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Ad Soyad</TableHead>
                  <TableHead>Şirket</TableHead>
                  <TableHead>İletişim</TableHead>
                  <TableHead>Durum</TableHead>
                  <TableHead>Eklenme</TableHead>
                  <TableHead className="text-right">İşlem</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contacts.map(c => (
                  <TableRow key={c.id} className="cursor-pointer hover:bg-muted/40" onClick={() => setSelectedContact(c)}>
                    <TableCell className="font-medium">{c.first_name} {c.last_name}</TableCell>
                    <TableCell className="text-muted-foreground text-sm">
                      {c.company && <span className="flex items-center gap-1"><Building2 className="h-3 w-3" />{c.company}</span>}
                      {c.job_title && <span className="text-xs text-muted-foreground/70">{c.job_title}</span>}
                    </TableCell>
                    <TableCell className="text-sm">
                      {c.email && <div className="flex items-center gap-1 text-muted-foreground"><Mail className="h-3 w-3" />{c.email}</div>}
                      {c.phone && <div className="flex items-center gap-1 text-muted-foreground"><Phone className="h-3 w-3" />{c.phone}</div>}
                    </TableCell>
                    <TableCell><StatusBadge status={c.status} /></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{format(new Date(c.created_at), "dd MMM yyyy")}</TableCell>
                    <TableCell className="text-right" onClick={e => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeleting(c)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Contact Detail Sheet */}
      <Sheet open={!!selectedContact} onOpenChange={o => !o && setSelectedContact(null)}>
        <SheetContent className="w-[480px] overflow-y-auto">
          {selectedContact && (
            <>
              <SheetHeader>
                <SheetTitle>{selectedContact.first_name} {selectedContact.last_name}</SheetTitle>
              </SheetHeader>
              <div className="mt-4 space-y-4">
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {selectedContact.email && <div><span className="text-muted-foreground">Email:</span> <a href={`mailto:${selectedContact.email}`} className="text-primary">{selectedContact.email}</a></div>}
                  {selectedContact.phone && <div><span className="text-muted-foreground">Tel:</span> {selectedContact.phone}</div>}
                  {selectedContact.company && <div><span className="text-muted-foreground">Şirket:</span> {selectedContact.company}</div>}
                  {selectedContact.job_title && <div><span className="text-muted-foreground">Unvan:</span> {selectedContact.job_title}</div>}
                  <div><span className="text-muted-foreground">Durum:</span> <StatusBadge status={selectedContact.status} /></div>
                </div>
                {selectedContact.notes && <p className="text-sm text-muted-foreground bg-muted/40 rounded p-2">{selectedContact.notes}</p>}

                <div className="border-t pt-4">
                  <h3 className="text-sm font-semibold mb-3">Aktivite Ekle</h3>
                  <div className="space-y-2">
                    <Select value={actForm.type} onValueChange={v => setActForm(f => ({ ...f, type: v as ActivityType }))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="note">Not</SelectItem>
                        <SelectItem value="call">Arama</SelectItem>
                        <SelectItem value="email">E-posta</SelectItem>
                        <SelectItem value="meeting">Toplantı</SelectItem>
                        <SelectItem value="task">Görev</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="Başlık" value={actForm.title} onChange={e => setActForm(f => ({ ...f, title: e.target.value }))} />
                    <Textarea rows={2} placeholder="Açıklama" value={actForm.description} onChange={e => setActForm(f => ({ ...f, description: e.target.value }))} />
                    <Button size="sm" disabled={!actForm.title || actM.isPending} onClick={() => actM.mutate()} className="w-full">
                      {actM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
                    </Button>
                  </div>
                </div>

                {activities.length > 0 && (
                  <div className="border-t pt-4 space-y-2">
                    <h3 className="text-sm font-semibold">Geçmiş</h3>
                    {activities.map(a => {
                      const Icon = activityIconMap[a.type as ActivityType] ?? MessageSquare;
                      return (
                        <div key={a.id} className="flex gap-2 text-sm">
                          <div className="mt-0.5"><Icon className="h-4 w-4 text-muted-foreground" /></div>
                          <div>
                            <p className="font-medium">{a.title}</p>
                            {a.description && <p className="text-muted-foreground text-xs">{a.description}</p>}
                            <p className="text-xs text-muted-foreground/60">{format(new Date(a.created_at), "dd MMM yyyy HH:mm")}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>

      {/* Upsert Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Kişiyi Düzenle" : "Yeni Kişi"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label>Ad *</Label>
              <Input value={form.first_name ?? ""} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Soyad *</Label>
              <Input value={form.last_name ?? ""} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>E-posta</Label>
              <Input type="email" value={form.email ?? ""} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Telefon</Label>
              <Input value={form.phone ?? ""} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Şirket</Label>
              <Input value={form.company ?? ""} onChange={e => setForm(f => ({ ...f, company: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Unvan</Label>
              <Input value={form.job_title ?? ""} onChange={e => setForm(f => ({ ...f, job_title: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Durum</Label>
              <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as ContactStatus }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(contactStatusMap).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Müşteri (Client)</Label>
              <Select value={form.client_id ?? "_none"} onValueChange={v => setForm(f => ({ ...f, client_id: v === "_none" ? undefined : v }))}>
                <SelectTrigger><SelectValue placeholder="Seç" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">— Yok —</SelectItem>
                  {(clientsData ?? []).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Notlar</Label>
              <Textarea rows={3} value={form.notes ?? ""} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>İptal</Button>
            <Button disabled={!form.first_name || !form.last_name || upsertM.isPending} onClick={() => upsertM.mutate()}>
              {upsertM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Kişiyi sil?</AlertDialogTitle>
            <AlertDialogDescription>Bu işlem geri alınamaz.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>İptal</AlertDialogCancel>
            <AlertDialogAction onClick={() => delM.mutate()}>Sil</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── DEALS TAB ───────────────────────────────────────────
function DealsTab() {
  const qc = useQueryClient();
  const list   = useServerFn(listDeals);
  const upsert = useServerFn(upsertDeal);
  const del    = useServerFn(deleteDeal);
  const listCont = useServerFn(listContacts);

  const [filterStage, setFilterStage] = useState("all");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<CrmDeal | null>(null);
  const [deleting, setDeleting] = useState<CrmDeal | null>(null);
  const [form, setForm] = useState<Partial<CrmDeal>>({
    title: "", value: 0, currency: "TRY", stage: "new", probability: 0, notes: "",
  });

  const { data, isLoading } = useQuery({
    queryKey: ["crm-deals", filterStage],
    queryFn: () => list({ data: filterStage !== "all" ? { stage: filterStage } : {} }),
  });

  const { data: contactsData } = useQuery({
    queryKey: ["crm-contacts-all"],
    queryFn: () => listCont({ data: {} }),
  });

  const { data: clientsData } = useQuery({
    queryKey: ["crm-clients"],
    queryFn: async () => {
      const { data } = await supabase.from("clients").select("id, name").order("name");
      return data ?? [];
    },
  });

  const upsertM = useMutation({
    mutationFn: () => upsert({ data: editing ? { ...form, id: editing.id } : form }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["crm-deals"] });
      setOpen(false); setEditing(null);
      setForm({ title: "", value: 0, currency: "TRY", stage: "new", probability: 0, notes: "" });
      toast.success(editing ? "Fırsat güncellendi" : "Fırsat eklendi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const delM = useMutation({
    mutationFn: () => del({ data: { id: deleting!.id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["crm-deals"] });
      setDeleting(null);
      toast.success("Fırsat silindi");
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openCreate = () => {
    setEditing(null);
    setForm({ title: "", value: 0, currency: "TRY", stage: "new", probability: 0, notes: "" });
    setOpen(true);
  };
  const openEdit = (d: CrmDeal) => {
    setEditing(d);
    setForm({ title: d.title, value: d.value, currency: d.currency, stage: d.stage, probability: d.probability, close_date: d.close_date ?? "", notes: d.notes ?? "", contact_id: d.contact_id ?? undefined, client_id: d.client_id ?? undefined });
    setOpen(true);
  };

  const deals = data?.deals ?? [];
  const totalValue = deals.filter(d => d.stage !== "lost").reduce((s, d) => s + Number(d.value), 0);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex gap-2">
          <Select value={filterStage} onValueChange={setFilterStage}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Tüm Aşamalar</SelectItem>
              {Object.entries(dealStageMap).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-4">
          <p className="text-sm text-muted-foreground">
            Toplam Potansiyel: <span className="font-semibold text-foreground">₺{totalValue.toLocaleString("tr-TR")}</span>
          </p>
          <Button onClick={openCreate}><Plus className="h-4 w-4 mr-2" />Fırsat Ekle</Button>
        </div>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-0">
          {isLoading ? (
            <div className="py-10 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>
          ) : deals.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted-foreground">Henüz fırsat yok.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Başlık</TableHead>
                  <TableHead>Kişi</TableHead>
                  <TableHead>Değer</TableHead>
                  <TableHead>Aşama</TableHead>
                  <TableHead>Olasılık</TableHead>
                  <TableHead>Kapanış</TableHead>
                  <TableHead className="text-right">İşlem</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deals.map(d => (
                  <TableRow key={d.id}>
                    <TableCell className="font-medium">{d.title}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {d.contact ? `${(d.contact as any).first_name} ${(d.contact as any).last_name}` : "—"}
                    </TableCell>
                    <TableCell className="font-medium">{d.currency} {Number(d.value).toLocaleString("tr-TR")}</TableCell>
                    <TableCell><StageBadge stage={d.stage} /></TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-muted rounded-full h-1.5">
                          <div className="bg-primary rounded-full h-1.5" style={{ width: `${d.probability}%` }} />
                        </div>
                        <span className="text-xs text-muted-foreground">%{d.probability}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {d.close_date ? format(new Date(d.close_date), "dd MMM yyyy") : "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => openEdit(d)}><Pencil className="h-4 w-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeleting(d)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editing ? "Fırsatı Düzenle" : "Yeni Fırsat"}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1">
              <Label>Başlık *</Label>
              <Input value={form.title ?? ""} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
            </div>
            <div className="space-y-1">
              <Label>Değer</Label>
              <Input type="number" min={0} value={form.value ?? 0} onChange={e => setForm(f => ({ ...f, value: parseFloat(e.target.value) || 0 }))} />
            </div>
            <div className="space-y-1">
              <Label>Para Birimi</Label>
              <Select value={form.currency ?? "TRY"} onValueChange={v => setForm(f => ({ ...f, currency: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="TRY">TRY ₺</SelectItem>
                  <SelectItem value="USD">USD $</SelectItem>
                  <SelectItem value="EUR">EUR €</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Aşama</Label>
              <Select value={form.stage} onValueChange={v => setForm(f => ({ ...f, stage: v as DealStage }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {Object.entries(dealStageMap).map(([k, v]) => (
                    <SelectItem key={k} value={k}>{v.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Olasılık (%)</Label>
              <Input type="number" min={0} max={100} value={form.probability ?? 0} onChange={e => setForm(f => ({ ...f, probability: parseInt(e.target.value) || 0 }))} />
            </div>
            <div className="space-y-1">
              <Label>Kişi</Label>
              <Select value={form.contact_id ?? "_none"} onValueChange={v => setForm(f => ({ ...f, contact_id: v === "_none" ? undefined : v }))}>
                <SelectTrigger><SelectValue placeholder="Seç" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="_none">— Yok —</SelectItem>
                  {(contactsData?.contacts ?? []).map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.first_name} {c.last_name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label>Kapanış Tarihi</Label>
              <Input type="date" value={form.close_date ?? ""} onChange={e => setForm(f => ({ ...f, close_date: e.target.value }))} />
            </div>
            <div className="col-span-2 space-y-1">
              <Label>Notlar</Label>
              <Textarea rows={2} value={form.notes ?? ""} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>İptal</Button>
            <Button disabled={!form.title || upsertM.isPending} onClick={() => upsertM.mutate()}>
              {upsertM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={o => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Fırsatı sil?</AlertDialogTitle>
            <AlertDialogDescription>Bu işlem geri alınamaz.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>İptal</AlertDialogCancel>
            <AlertDialogAction onClick={() => delM.mutate()}>Sil</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ── PIPELINE TAB (Kanban) ───────────────────────────────
function PipelineTab() {
  const list = useServerFn(listDeals);
  const upsert = useServerFn(upsertDeal);
  const qc = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["crm-deals", "all"],
    queryFn: () => list({ data: {} }),
  });

  const deals = data?.deals ?? [];
  const stageKeys = Object.keys(dealStageMap) as DealStage[];

  const moveStage = async (deal: CrmDeal, newStage: DealStage) => {
    const probability: Record<DealStage, number> = {
      new: 10, contacted: 25, proposal: 50, negotiation: 75, won: 100, lost: 0,
    };
    try {
      await upsert({ data: { id: deal.id, stage: newStage, probability: probability[newStage] } });
      qc.invalidateQueries({ queryKey: ["crm-deals"] });
      toast.success("Aşama güncellendi");
    } catch (e: any) {
      toast.error(e.message);
    }
  };

  if (isLoading) {
    return <div className="py-10 flex justify-center"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground" /></div>;
  }

  return (
    <div className="overflow-x-auto pb-4">
      <div className="flex gap-3 min-w-max">
        {stageKeys.map(stage => {
          const stageDeals = deals.filter(d => d.stage === stage);
          const stageTotal = stageDeals.reduce((s, d) => s + Number(d.value), 0);
          const { label, color } = dealStageMap[stage];
          return (
            <div key={stage} className="w-64 flex-shrink-0">
              <div className={`rounded-t-lg px-3 py-2 flex items-center justify-between ${color}`}>
                <span className="text-xs font-semibold">{label}</span>
                <span className="text-xs">{stageDeals.length}</span>
              </div>
              <div className="bg-muted/30 rounded-b-lg min-h-[200px] p-2 space-y-2 border border-t-0 border-border/40">
                {stageDeals.length === 0 && (
                  <p className="text-xs text-muted-foreground text-center py-4">Fırsat yok</p>
                )}
                {stageDeals.map(d => (
                  <Card key={d.id} className="border-border/60 cursor-grab hover:shadow-sm transition-shadow">
                    <CardContent className="p-3 space-y-1">
                      <p className="text-sm font-medium leading-tight">{d.title}</p>
                      {d.contact && (
                        <p className="text-xs text-muted-foreground">{(d.contact as any).first_name} {(d.contact as any).last_name}</p>
                      )}
                      <p className="text-xs font-semibold text-primary">{d.currency} {Number(d.value).toLocaleString("tr-TR")}</p>
                      <div className="flex gap-1 flex-wrap pt-1">
                        {stageKeys.filter(s => s !== stage).map(s => (
                          <button
                            key={s}
                            onClick={() => moveStage(d, s)}
                            className={`text-[10px] rounded px-1.5 py-0.5 ${dealStageMap[s].color} opacity-70 hover:opacity-100 transition-opacity`}
                          >
                            → {dealStageMap[s].label}
                          </button>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              {stageTotal > 0 && (
                <div className="text-right pr-1 pt-1">
                  <span className="text-xs text-muted-foreground">₺{stageTotal.toLocaleString("tr-TR")}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
