import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { listSeoReports, createSeoReport } from "@/lib/seo.functions";
import { useAuth } from "@/lib/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Search, FileText, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/seo")({
  component: SeoPage,
});

type Client = { id: string; name: string };

function SeoPage() {
  const { role, user } = useAuth();
  const isStaff = role === "admin" || role === "super_admin";
  const qc = useQueryClient();
  const list = useServerFn(listSeoReports);
  const create = useServerFn(createSeoReport);

  const { data: clients = [] } = useQuery({
    queryKey: ["seo-clients", role, user?.id],
    queryFn: async (): Promise<Client[]> => {
      const { data, error } = await supabase.from("clients").select("id, name").order("name");
      if (error) throw error;
      return data ?? [];
    },
  });

  const [clientId, setClientId] = useState<string>("");
  const activeClientId = useMemo(() => {
    if (clientId) return clientId;
    return clients[0]?.id ?? "";
  }, [clientId, clients]);

  const { data: reportsData } = useQuery({
    queryKey: ["seo-reports", activeClientId],
    queryFn: () => list({ data: activeClientId ? { clientId: activeClientId } : {} }),
    enabled: !!activeClientId || !isStaff,
  });

  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", period_start: "", period_end: "", summary: "" });

  const createMut = useMutation({
    mutationFn: () =>
      create({
        data: {
          client_id: activeClientId,
          title: form.title,
          period_start: form.period_start,
          period_end: form.period_end,
          summary: form.summary || null,
        },
      }),
    onSuccess: () => {
      toast.success("Rapor oluşturuldu");
      setOpen(false);
      setForm({ title: "", period_start: "", period_end: "", summary: "" });
      qc.invalidateQueries({ queryKey: ["seo-reports"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const reports = reportsData?.reports ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight">
            <Search className="h-6 w-6" /> SEO Raporları
          </h1>
          <p className="text-sm text-muted-foreground">
            Search Console ve Google Analytics 4 verilerinden oluşturulan dönem raporları.
          </p>
        </div>
        {isStaff && (
          <div className="flex items-center gap-2">
            {clients.length > 0 && (
              <Select value={activeClientId} onValueChange={setClientId}>
                <SelectTrigger className="w-[220px]">
                  <SelectValue placeholder="Müşteri seç" />
                </SelectTrigger>
                <SelectContent>
                  {clients.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button disabled={!activeClientId}>
                  <Plus className="mr-1 h-4 w-4" /> Yeni Rapor
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Yeni SEO Raporu</DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <div className="space-y-1">
                    <Label>Başlık</Label>
                    <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Mayıs 2026 SEO Raporu" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label>Başlangıç</Label>
                      <Input type="date" value={form.period_start} onChange={(e) => setForm({ ...form, period_start: e.target.value })} />
                    </div>
                    <div className="space-y-1">
                      <Label>Bitiş</Label>
                      <Input type="date" value={form.period_end} onChange={(e) => setForm({ ...form, period_end: e.target.value })} />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label>Özet</Label>
                    <Textarea rows={4} value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    onClick={() => createMut.mutate()}
                    disabled={createMut.isPending || !form.title || !form.period_start || !form.period_end}
                  >
                    {createMut.isPending ? "Oluşturuluyor…" : "Oluştur"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        )}
      </div>

      <Card className="border-border/60">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Raporlar
          </CardTitle>
        </CardHeader>
        <CardContent>
          {reports.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">Henüz rapor yok.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Başlık</TableHead>
                  <TableHead>Dönem</TableHead>
                  <TableHead>Durum</TableHead>
                  <TableHead>Oluşturma</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.title}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.period_start} → {r.period_end}
                    </TableCell>
                    <TableCell>
                      <Badge variant={r.status === "published" ? "default" : "secondary"}>{r.status}</Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(r.created_at).toLocaleDateString()}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}