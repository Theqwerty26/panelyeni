import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Plus, Trash2, KeyRound, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/lib/auth-context";
import {
  listUsers, createUser, updateUserRole, resetUserPassword, deleteUser, assignClientToAdmin,
} from "@/lib/admin-users.functions";

type Role = "super_admin" | "admin" | "client";

export const Route = createFileRoute("/_authenticated/super-admin/settings/users")({
  component: UsersPage,
});

function UsersPage() {
  const { user: me } = useAuth();
  const list = useServerFn(listUsers);
  const create = useServerFn(createUser);
  const updateRole = useServerFn(updateUserRole);
  const reset = useServerFn(resetUserPassword);
  const del = useServerFn(deleteUser);
  const assign = useServerFn(assignClientToAdmin);
  const qc = useQueryClient();

  const q = useQuery({ queryKey: ["admin-users"], queryFn: () => list() });
  const invalidate = () => qc.invalidateQueries({ queryKey: ["admin-users"] });

  const [createOpen, setCreateOpen] = useState(false);
  const [form, setForm] = useState({ email: "", password: "", role: "client" as Role });
  const [resetting, setResetting] = useState<{ id: string; email: string } | null>(null);
  const [newPwd, setNewPwd] = useState("");
  const [deleting, setDeleting] = useState<{ id: string; email: string } | null>(null);

  const createM = useMutation({
    mutationFn: () => create({ data: form }),
    onSuccess: () => {
      toast.success("User created");
      setCreateOpen(false);
      setForm({ email: "", password: "", role: "client" });
      invalidate();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const roleM = useMutation({
    mutationFn: (v: { user_id: string; role: Role }) => updateRole({ data: v }),
    onSuccess: () => { toast.success("Role updated"); invalidate(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const resetM = useMutation({
    mutationFn: () => reset({ data: { user_id: resetting!.id, password: newPwd } }),
    onSuccess: () => { toast.success("Password reset"); setResetting(null); setNewPwd(""); },
    onError: (e: Error) => toast.error(e.message),
  });
  const delM = useMutation({
    mutationFn: () => del({ data: { user_id: deleting!.id } }),
    onSuccess: () => { toast.success("User deleted"); setDeleting(null); invalidate(); },
    onError: (e: Error) => toast.error(e.message),
  });
  const assignM = useMutation({
    mutationFn: (v: { client_id: string; admin_id: string | null }) => assign({ data: v }),
    onSuccess: () => { toast.success("Assignment updated"); invalidate(); },
    onError: (e: Error) => toast.error(e.message),
  });

  const users = q.data?.users ?? [];
  const clients = q.data?.clients ?? [];
  const admins = users.filter((u) => u.role === "admin" || u.role === "super_admin");

  return (
    <div className="space-y-6 max-w-5xl">
      <Card>
        <CardHeader className="flex-row flex items-start justify-between gap-3">
          <div>
            <CardTitle>Users</CardTitle>
            <CardDescription>Create admins and clients, change roles, reset passwords.</CardDescription>
          </div>
          <Button onClick={() => setCreateOpen(true)}><Plus className="h-4 w-4" /> New user</Button>
        </CardHeader>
        <CardContent>
          {q.isLoading ? (
            <div className="py-8 text-center text-muted-foreground"><Loader2 className="inline h-4 w-4 animate-spin" /> Loading…</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead>Last sign-in</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map((u) => (
                  <TableRow key={u.id}>
                    <TableCell className="font-medium">
                      {u.email}{me?.id === u.id && <Badge variant="secondary" className="ml-2">you</Badge>}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={u.role}
                        onValueChange={(v) => roleM.mutate({ user_id: u.id, role: v as Role })}
                        disabled={me?.id === u.id}
                      >
                        <SelectTrigger className="w-36 h-8"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="super_admin">Super Admin</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="client">Client</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {u.created_at ? format(new Date(u.created_at), "PP") : "—"}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {u.last_sign_in_at ? format(new Date(u.last_sign_in_at), "PPp") : "never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" onClick={() => setResetting({ id: u.id, email: u.email })}>
                        <KeyRound className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost" size="icon"
                        onClick={() => setDeleting({ id: u.id, email: u.email })}
                        disabled={me?.id === u.id}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Client → Admin assignment</CardTitle>
          <CardDescription>Assign each client to a managing admin.</CardDescription>
        </CardHeader>
        <CardContent>
          {clients.length === 0 ? (
            <p className="text-sm text-muted-foreground">No clients.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Client</TableHead>
                  <TableHead>Assigned admin</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((c) => (
                  <TableRow key={c.id}>
                    <TableCell className="font-medium">{c.name}</TableCell>
                    <TableCell>
                      <Select
                        value={c.assigned_admin_id ?? "none"}
                        onValueChange={(v) =>
                          assignM.mutate({ client_id: c.id, admin_id: v === "none" ? null : v })
                        }
                      >
                        <SelectTrigger className="w-72 h-8"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">— Unassigned —</SelectItem>
                          {admins.map((a) => (
                            <SelectItem key={a.id} value={a.id}>{a.email}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create user</DialogTitle></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); createM.mutate(); }}>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Password (min 8 chars)</Label>
              <Input type="password" required minLength={8} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={form.role} onValueChange={(v) => setForm({ ...form, role: v as Role })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="super_admin">Super Admin</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="client">Client</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={createM.isPending}>
                {createM.isPending && <Loader2 className="h-4 w-4 animate-spin" />} Create
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resetting} onOpenChange={(o) => !o && setResetting(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Reset password — {resetting?.email}</DialogTitle></DialogHeader>
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); resetM.mutate(); }}>
            <div className="space-y-2">
              <Label>New password (min 8)</Label>
              <Input type="password" required minLength={8} value={newPwd} onChange={(e) => setNewPwd(e.target.value)} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setResetting(null)}>Cancel</Button>
              <Button type="submit" disabled={resetM.isPending}>Reset</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete user</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting?.email} will be permanently removed. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => delM.mutate()}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}