import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCircle2, XCircle, Loader2, PlugZap, Save } from "lucide-react";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  getGoogleAdsSettings,
  saveGoogleAdsSettings,
  testGoogleAdsConnection,
} from "@/lib/google-ads.functions";

export const Route = createFileRoute("/_authenticated/super-admin/settings/google-ads")({
  component: GoogleAdsSettings,
});

type FormState = {
  developer_token: string;
  client_id: string;
  client_secret: string;
  refresh_token: string;
  login_customer_id: string;
  mcc_customer_id: string;
  test_customer_id: string;
  api_version: string;
};

const empty: FormState = {
  developer_token: "",
  client_id: "",
  client_secret: "",
  refresh_token: "",
  login_customer_id: "",
  mcc_customer_id: "",
  test_customer_id: "",
  api_version: "v17",
};

function GoogleAdsSettings() {
  const get = useServerFn(getGoogleAdsSettings);
  const save = useServerFn(saveGoogleAdsSettings);
  const test = useServerFn(testGoogleAdsConnection);
  const qc = useQueryClient();
  const [form, setForm] = useState<FormState>(empty);

  const settingsQ = useQuery({ queryKey: ["gads-settings"], queryFn: () => get() });

  useEffect(() => {
    const s = settingsQ.data?.settings;
    if (s) {
      setForm({
        developer_token: s.developer_token ?? "",
        client_id: s.client_id ?? "",
        client_secret: s.client_secret ?? "",
        refresh_token: s.refresh_token ?? "",
        login_customer_id: s.login_customer_id ?? "",
        mcc_customer_id: s.mcc_customer_id ?? "",
        test_customer_id: s.test_customer_id ?? "",
        api_version: s.api_version ?? "v17",
      });
    }
  }, [settingsQ.data]);

  const saveM = useMutation({
    mutationFn: () => save({ data: form }),
    onSuccess: () => {
      toast.success("Settings saved");
      qc.invalidateQueries({ queryKey: ["gads-settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const testM = useMutation({
    mutationFn: () => test(),
    onSuccess: (r) => {
      if (r.ok) toast.success(r.message);
      else toast.error(r.message);
      qc.invalidateQueries({ queryKey: ["gads-settings"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const s = settingsQ.data?.settings;
  const status = s?.last_test_status;

  const field = (k: keyof FormState) => ({
    value: form[k],
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value })),
  });

  return (
    <div className="space-y-6 max-w-3xl">
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <CardTitle>Google Ads API</CardTitle>
              <CardDescription>OAuth2 credentials and developer token used to fetch live campaign data.</CardDescription>
            </div>
            {status && (
              <Badge variant={status === "ok" ? "default" : "destructive"} className="gap-1">
                {status === "ok" ? <CheckCircle2 className="h-3 w-3" /> : <XCircle className="h-3 w-3" />}
                {status === "ok" ? "Connected" : "Failed"}
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Developer token</Label>
              <Input placeholder="abc123…" {...field("developer_token")} />
            </div>
            <div className="space-y-2">
              <Label>API version</Label>
              <Input placeholder="v17" {...field("api_version")} />
            </div>
            <div className="space-y-2">
              <Label>OAuth Client ID</Label>
              <Input placeholder="xxxxx.apps.googleusercontent.com" {...field("client_id")} />
            </div>
            <div className="space-y-2">
              <Label>OAuth Client Secret</Label>
              <Input type="password" {...field("client_secret")} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Refresh token</Label>
              <Input type="password" placeholder="1//04…" {...field("refresh_token")} />
            </div>
            <div className="space-y-2">
              <Label>Login Customer ID (MCC)</Label>
              <Input placeholder="123-456-7890" {...field("login_customer_id")} />
            </div>
            <div className="space-y-2">
              <Label>Default MCC ID</Label>
              <Input placeholder="123-456-7890" {...field("mcc_customer_id")} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Test customer ID (optional)</Label>
              <Input placeholder="987-654-3210" {...field("test_customer_id")} />
            </div>
          </div>

          {s?.last_tested_at && (
            <div className="rounded-md border border-border/60 bg-muted/30 p-3 text-sm">
              <div className="text-xs text-muted-foreground">
                Last tested: {format(new Date(s.last_tested_at), "PPp")}
              </div>
              <div className="mt-1">{s.last_test_message}</div>
            </div>
          )}

          <div className="flex flex-wrap gap-2 pt-2">
            <Button onClick={() => saveM.mutate()} disabled={saveM.isPending}>
              {saveM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save
            </Button>
            <Button variant="outline" onClick={() => testM.mutate()} disabled={testM.isPending}>
              {testM.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlugZap className="h-4 w-4" />}
              Test connection
            </Button>
          </div>

          <p className="text-xs text-muted-foreground pt-2">
            Existing secrets are masked with •. Leave a field blank or masked to keep the stored value.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}