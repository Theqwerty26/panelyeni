import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listSeoProviders, saveSeoProvider, testSeoProvider } from "@/lib/seo-providers.functions";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Search, Zap, Loader2, KeyRound } from "lucide-react";
import { toast } from "sonner";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/_authenticated/super-admin/settings/seo-providers")({
  component: ProvidersPage,
});

type Provider = {
  id: string;
  provider: "semrush" | "ahrefs" | "serpapi";
  enabled: boolean;
  base_url: string | null;
  default_database: string | null;
  rate_limit_per_minute: number | null;
  last_test_status: string | null;
  last_test_message: string | null;
  has_api_key: boolean;
};

const LABELS: Record<string, { name: string; desc: string }> = {
  semrush: { name: "SEMrush", desc: "Anahtar kelime ve organik veri (SEMRUSH_API_KEY)" },
  ahrefs: { name: "Ahrefs", desc: "Backlink ve domain otoritesi (AHREFS_API_KEY)" },
  serpapi: { name: "SerpAPI", desc: "Gerçek zamanlı SERP sıralaması (SERPAPI_KEY)" },
};

function ProvidersPage() {
  const list = useServerFn(listSeoProviders);
  const { data } = useQuery({ queryKey: ["seo-providers"], queryFn: () => list() });
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Search className="h-5 w-5" /> 3rd-Party SEO Sağlayıcıları</CardTitle>
          <CardDescription>SEMrush, Ahrefs, SerpAPI bağlantıları. API anahtarları proje secret'larında tutulur.</CardDescription>
        </CardHeader>
      </Card>
      <div className="grid gap-4">
        {(data?.providers ?? []).map(p => <ProviderCard key={p.id} provider={p as Provider} />)}
      </div>
    </div>
  );
}

function ProviderCard({ provider }: { provider: Provider }) {
  const meta = LABELS[provider.provider];
  const save = useServerFn(saveSeoProvider);
  const test = useServerFn(testSeoProvider);
  const qc = useQueryClient();
  const [form, setForm] = useState({
    enabled: provider.enabled,
    base_url: provider.base_url ?? "",
    default_database: provider.default_database ?? "",
    rate_limit_per_minute: provider.rate_limit_per_minute ?? 30,
  });
  useEffect(() => {
    setForm({
      enabled: provider.enabled,
      base_url: provider.base_url ?? "",
      default_database: provider.default_database ?? "",
      rate_limit_per_minute: provider.rate_limit_per_minute ?? 30,
    });
  }, [provider]);

  const saveMut = useMutation({
    mutationFn: () => save({ data: { provider: provider.provider, ...form, base_url: form.base_url || null, default_database: form.default_database || null } }),
    onSuccess: () => { toast.success("Kaydedildi"); qc.invalidateQueries({ queryKey: ["seo-providers"] }); },
    onError: (e: Error) => toast.error(e.message),
  });
  const testMut = useMutation({
    mutationFn: () => test({ data: { provider: provider.provider } }),
    onSuccess: (r) => { (r as { ok: boolean; message: string }).ok ? toast.success(r.message) : toast.error(r.message); qc.invalidateQueries({ queryKey: ["seo-providers"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">{meta.name}</CardTitle>
            <CardDescription>{meta.desc}</CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {provider.has_api_key
              ? <Badge variant="secondary"><KeyRound className="mr-1 h-3 w-3" />Key OK</Badge>
              : <Badge variant="destructive">No Key</Badge>}
            {provider.last_test_status && (
              <Badge variant={provider.last_test_status === "success" ? "default" : "destructive"}>
                {provider.last_test_status}
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid gap-3 md:grid-cols-3">
          <div className="space-y-1"><Label>Base URL</Label>
            <Input value={form.base_url} onChange={e => setForm({ ...form, base_url: e.target.value })} /></div>
          <div className="space-y-1"><Label>Varsayılan veritabanı</Label>
            <Input placeholder="us, tr…" value={form.default_database} onChange={e => setForm({ ...form, default_database: e.target.value })} /></div>
          <div className="space-y-1"><Label>Rate limit / dk</Label>
            <Input type="number" value={form.rate_limit_per_minute} onChange={e => setForm({ ...form, rate_limit_per_minute: Number(e.target.value) })} /></div>
        </div>
        <div className="flex items-center gap-2">
          <Switch checked={form.enabled} onCheckedChange={v => setForm({ ...form, enabled: v })} />
          <Label>Etkin</Label>
        </div>
        {provider.last_test_message && (
          <p className="text-xs text-muted-foreground">{provider.last_test_message}</p>
        )}
        <div className="flex gap-2">
          <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>Kaydet</Button>
          <Button variant="outline" onClick={() => testMut.mutate()} disabled={testMut.isPending || !provider.has_api_key}>
            {testMut.isPending ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Zap className="mr-1 h-4 w-4" />}
            Test bağlantısı
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}