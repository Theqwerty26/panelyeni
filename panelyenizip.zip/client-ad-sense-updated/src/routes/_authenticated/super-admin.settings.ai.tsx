import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { listAiProviders, upsertAiProvider } from "@/lib/app-settings.functions";

export const Route = createFileRoute("/_authenticated/super-admin/settings/ai")({
  component: AiPage,
});

type Provider = "openai" | "claude" | "gemini" | "deepseek";
const providers: { id: Provider; label: string; defaultModel: string }[] = [
  { id: "openai", label: "OpenAI", defaultModel: "gpt-4o-mini" },
  { id: "claude", label: "Claude", defaultModel: "claude-3-5-sonnet-latest" },
  { id: "gemini", label: "Gemini", defaultModel: "gemini-1.5-flash" },
  { id: "deepseek", label: "DeepSeek", defaultModel: "deepseek-chat" },
];

type Form = {
  enabled: boolean;
  is_default: boolean;
  model: string;
  base_url: string;
  max_tokens: number;
  temperature: number;
  system_prompt: string;
  api_key: string;
};

function emptyForm(defaultModel: string): Form {
  return {
    enabled: false,
    is_default: false,
    model: defaultModel,
    base_url: "",
    max_tokens: 1024,
    temperature: 0.7,
    system_prompt: "You are a helpful Google Ads marketing analyst.",
    api_key: "",
  };
}

function AiPage() {
  const list = useServerFn(listAiProviders);
  const upsert = useServerFn(upsertAiProvider);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["ai-providers"], queryFn: () => list() });

  const [forms, setForms] = useState<Record<Provider, Form>>({
    openai: emptyForm("gpt-4o-mini"),
    claude: emptyForm("claude-3-5-sonnet-latest"),
    gemini: emptyForm("gemini-1.5-flash"),
    deepseek: emptyForm("deepseek-chat"),
  });

  useEffect(() => {
    const data = q.data?.providers;
    if (!data) return;
    setForms((prev) => {
      const next = { ...prev };
      for (const p of data) {
        const id = p.provider as Provider;
        if (!providers.find((x) => x.id === id)) continue;
        next[id] = {
          enabled: p.enabled,
          is_default: p.is_default,
          model: p.model ?? providers.find((x) => x.id === id)!.defaultModel,
          base_url: p.base_url ?? "",
          max_tokens: p.max_tokens ?? 1024,
          temperature: Number(p.temperature ?? 0.7),
          system_prompt: p.system_prompt ?? "",
          api_key: p.api_key ?? "",
        };
      }
      return next;
    });
  }, [q.data]);

  const m = useMutation({
    mutationFn: (provider: Provider) => {
      const f = forms[provider];
      return upsert({
        data: {
          provider,
          enabled: f.enabled,
          is_default: f.is_default,
          model: f.model,
          base_url: f.base_url || null,
          max_tokens: f.max_tokens,
          temperature: f.temperature,
          system_prompt: f.system_prompt,
          api_key: f.api_key,
        },
      });
    },
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["ai-providers"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  const update = (id: Provider, patch: Partial<Form>) =>
    setForms((s) => ({ ...s, [id]: { ...s[id], ...patch } }));

  return (
    <Card className="max-w-3xl">
      <CardHeader>
        <CardTitle>AI Providers</CardTitle>
        <CardDescription>Configure OpenAI, Claude, Gemini and DeepSeek. One can be marked as default.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="openai">
          <TabsList>
            {providers.map((p) => (
              <TabsTrigger key={p.id} value={p.id} className="gap-2">
                {p.label}
                {forms[p.id].is_default && <Badge variant="secondary" className="text-[10px]">default</Badge>}
              </TabsTrigger>
            ))}
          </TabsList>
          {providers.map((p) => {
            const f = forms[p.id];
            return (
              <TabsContent key={p.id} value={p.id} className="space-y-4 mt-4">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <Switch checked={f.enabled} onCheckedChange={(v) => update(p.id, { enabled: v })} />
                    <Label>Enabled</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Switch checked={f.is_default} onCheckedChange={(v) => update(p.id, { is_default: v })} />
                    <Label>Set as default</Label>
                  </div>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Model</Label>
                    <Input value={f.model} onChange={(e) => update(p.id, { model: e.target.value })} />
                  </div>
                  <div className="space-y-2">
                    <Label>Base URL (optional)</Label>
                    <Input value={f.base_url} onChange={(e) => update(p.id, { base_url: e.target.value })} placeholder="https://api…" />
                  </div>
                  <div className="space-y-2">
                    <Label>Max tokens</Label>
                    <Input type="number" value={f.max_tokens} onChange={(e) => update(p.id, { max_tokens: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2">
                    <Label>Temperature</Label>
                    <Input type="number" step="0.1" min="0" max="2" value={f.temperature} onChange={(e) => update(p.id, { temperature: Number(e.target.value) })} />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>API key</Label>
                    <Input type="password" value={f.api_key} onChange={(e) => update(p.id, { api_key: e.target.value })} placeholder="sk-…" />
                    <p className="text-xs text-muted-foreground">Existing key is masked. Leave masked or empty to keep stored value.</p>
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label>System prompt</Label>
                    <Textarea rows={3} value={f.system_prompt} onChange={(e) => update(p.id, { system_prompt: e.target.value })} />
                  </div>
                </div>
                <Button onClick={() => m.mutate(p.id)} disabled={m.isPending}>
                  {m.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save {p.label}
                </Button>
              </TabsContent>
            );
          })}
        </Tabs>
      </CardContent>
    </Card>
  );
}