import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getAppSettings, saveAppSettings } from "@/lib/app-settings.functions";

export const Route = createFileRoute("/_authenticated/super-admin/settings/branding")({
  component: BrandingPage,
});

function BrandingPage() {
  const get = useServerFn(getAppSettings);
  const save = useServerFn(saveAppSettings);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["app-settings", "branding"], queryFn: () => get({ data: { key: "branding" } }) });
  const [v, setV] = useState({ logo_url: "", primary_color: "#6366f1", login_background_url: "", company_name: "" });

  useEffect(() => {
    const x = q.data?.value as Record<string, string> | undefined;
    if (x) setV({
      logo_url: x.logo_url ?? "",
      primary_color: x.primary_color ?? "#6366f1",
      login_background_url: x.login_background_url ?? "",
      company_name: x.company_name ?? "",
    });
  }, [q.data]);

  const m = useMutation({
    mutationFn: () => save({ data: { key: "branding", value: v } }),
    onSuccess: () => { toast.success("Saved"); qc.invalidateQueries({ queryKey: ["app-settings", "branding"] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>Branding</CardTitle>
        <CardDescription>Logo, colors, login screen.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Company / agency name</Label>
          <Input value={v.company_name} onChange={(e) => setV({ ...v, company_name: e.target.value })} placeholder="Acme Marketing" />
        </div>
        <div className="space-y-2">
          <Label>Logo URL</Label>
          <Input value={v.logo_url} onChange={(e) => setV({ ...v, logo_url: e.target.value })} placeholder="https://…/logo.png" />
          {v.logo_url && <img src={v.logo_url} alt="" className="h-12 mt-2 rounded border border-border/60 bg-muted/30" />}
        </div>
        <div className="space-y-2">
          <Label>Primary color</Label>
          <div className="flex gap-2 items-center">
            <Input type="color" value={v.primary_color} onChange={(e) => setV({ ...v, primary_color: e.target.value })} className="w-16 p-1 h-9" />
            <Input value={v.primary_color} onChange={(e) => setV({ ...v, primary_color: e.target.value })} />
          </div>
        </div>
        <div className="space-y-2">
          <Label>Login background URL (optional)</Label>
          <Input value={v.login_background_url} onChange={(e) => setV({ ...v, login_background_url: e.target.value })} />
        </div>
        <Button onClick={() => m.mutate()} disabled={m.isPending}>
          {m.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save
        </Button>
      </CardContent>
    </Card>
  );
}