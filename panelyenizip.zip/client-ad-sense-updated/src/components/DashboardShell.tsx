import type { ReactNode } from "react";
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "./AppSidebar";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { ThemeToggle } from "./ThemeToggle";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { Badge } from "@/components/ui/badge";

export function DashboardShell({ children }: { children: ReactNode }) {
  const { role } = useAuth();
  const { t } = useI18n();
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <SidebarInset>
          <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b bg-background/80 backdrop-blur px-4">
            <SidebarTrigger />
            <div className="flex-1" />
            {role && (
              <Badge variant="secondary" className="hidden sm:inline-flex">
                {role === "admin" ? (t.common.admin as string) : (t.common.client as string)}
              </Badge>
            )}
            <LanguageSwitcher />
            <ThemeToggle />
          </header>
          <main className="flex-1 p-4 md:p-6">{children}</main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}