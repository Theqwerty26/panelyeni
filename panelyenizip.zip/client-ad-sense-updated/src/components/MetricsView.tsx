import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, MousePointerClick, Eye, Target, Percent, TrendingUp } from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { KpiCard } from "./KpiCard";
import { supabase } from "@/integrations/supabase/client";
import { useI18n } from "@/i18n/I18nProvider";
import { aggregateMetrics, groupByCampaign, groupByDate, type Metric } from "@/lib/metrics";
import { fmtCurrency, fmtNumber, fmtPct } from "@/lib/format";

interface Props {
  clientId: string;
  clientLabel?: string;
  showOnlyTable?: boolean;
}

export function MetricsView({ clientId, clientLabel, showOnlyTable }: Props) {
  const { t } = useI18n();
  const [days, setDays] = useState(30);
  const [campaign, setCampaign] = useState<string>("__all__");

  const { data: rows = [], isLoading } = useQuery({
    queryKey: ["metrics", clientId, days],
    queryFn: async () => {
      const since = new Date();
      since.setDate(since.getDate() - (days - 1));
      const { data, error } = await supabase
        .from("ad_metrics")
        .select("*")
        .eq("client_id", clientId)
        .gte("date", since.toISOString().slice(0, 10))
        .order("date", { ascending: true });
      if (error) throw error;
      return (data ?? []) as Metric[];
    },
    enabled: !!clientId,
  });

  const filtered = useMemo(
    () => (campaign === "__all__" ? rows : rows.filter(r => r.campaign_name === campaign)),
    [rows, campaign]
  );

  const totals = useMemo(() => aggregateMetrics(filtered), [filtered]);
  const byDate = useMemo(() => groupByDate(filtered), [filtered]);
  const byCampaign = useMemo(() => groupByCampaign(filtered), [filtered]);
  const allCampaignNames = useMemo(
    () => Array.from(new Set(rows.map(r => r.campaign_name))).sort(),
    [rows]
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {clientLabel && (
        <div className="text-sm text-muted-foreground">
          {t.common.client as string}: <span className="font-medium text-foreground">{clientLabel}</span>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">{t.filters.dateRange as string}</span>
          <Select value={String(days)} onValueChange={v => setDays(Number(v))}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="7">{t.filters.last7 as string}</SelectItem>
              <SelectItem value="14">{t.filters.last14 as string}</SelectItem>
              <SelectItem value="30">{t.filters.last30 as string}</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">{t.filters.campaign as string}</span>
          <Select value={campaign} onValueChange={setCampaign}>
            <SelectTrigger className="w-[220px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="__all__">{t.filters.allCampaigns as string}</SelectItem>
              {allCampaignNames.map(n => (
                <SelectItem key={n} value={n}>{n}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {!showOnlyTable && (
        <>
          {/* KPIs */}
          <div className="grid gap-4 grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
            <KpiCard label={t.kpi.totalSpend as string} value={fmtCurrency(totals.cost)} icon={DollarSign} />
            <KpiCard label={t.kpi.clicks as string} value={fmtNumber(totals.clicks)} icon={MousePointerClick} accent="from-chart-2 to-primary" />
            <KpiCard label={t.kpi.impressions as string} value={fmtNumber(totals.impressions)} icon={Eye} accent="from-chart-3 to-chart-2" />
            <KpiCard label={t.kpi.conversions as string} value={fmtNumber(totals.conversions)} icon={Target} accent="from-chart-4 to-chart-1" />
            <KpiCard label={t.kpi.ctr as string} value={fmtPct(totals.ctr)} icon={Percent} accent="from-chart-5 to-chart-4" />
            <KpiCard label={t.kpi.cpc as string} value={fmtCurrency(totals.cpc)} icon={TrendingUp} accent="from-primary to-chart-5" />
          </div>

          {/* Charts */}
          <div className="grid gap-4 lg:grid-cols-2">
            <Card className="border-border/60">
              <CardHeader><CardTitle className="text-base">{t.charts.dailySpend as string}</CardTitle></CardHeader>
              <CardContent className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={byDate} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                    <defs>
                      <linearGradient id="spendGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} stroke="var(--color-muted-foreground)" />
                    <YAxis tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" />
                    <Tooltip
                      contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }}
                      formatter={(v: number) => fmtCurrency(v)}
                    />
                    <Area type="monotone" dataKey="cost" stroke="var(--color-primary)" fill="url(#spendGrad)" strokeWidth={2} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/60">
              <CardHeader><CardTitle className="text-base">{t.charts.clicksVsConversions as string}</CardTitle></CardHeader>
              <CardContent className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={byDate} margin={{ left: 0, right: 8, top: 8, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} stroke="var(--color-muted-foreground)" />
                    <YAxis tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" />
                    <Tooltip contentStyle={{ background: "var(--color-popover)", border: "1px solid var(--color-border)", borderRadius: 8, fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    <Bar dataKey="clicks" fill="var(--color-chart-2)" radius={[4, 4, 0, 0]} />
                    <Bar dataKey="conversions" fill="var(--color-chart-4)" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </>
      )}

      {/* Campaign table */}
      <Card className="border-border/60">
        <CardHeader><CardTitle className="text-base">{t.table.campaignList as string}</CardTitle></CardHeader>
        <CardContent>
          {byCampaign.length === 0 ? (
            <p className="py-8 text-center text-sm text-muted-foreground">{t.table.noCampaigns as string}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t.table.campaignName as string}</TableHead>
                  <TableHead className="text-right">{t.table.spend as string}</TableHead>
                  <TableHead className="text-right">{t.table.clicks as string}</TableHead>
                  <TableHead className="text-right">{t.table.conversions as string}</TableHead>
                  <TableHead className="text-right">{t.table.ctr as string}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {byCampaign.map(c => {
                  const ctr = c.impressions ? (c.clicks / c.impressions) * 100 : 0;
                  return (
                    <TableRow key={c.name}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell className="text-right">{fmtCurrency(c.cost)}</TableCell>
                      <TableCell className="text-right">{fmtNumber(c.clicks)}</TableCell>
                      <TableCell className="text-right">{fmtNumber(c.conversions)}</TableCell>
                      <TableCell className="text-right">{fmtPct(ctr)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}