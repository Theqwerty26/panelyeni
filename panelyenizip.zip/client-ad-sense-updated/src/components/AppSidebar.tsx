import { Link, useRouterState } from "@tanstack/react-router";
import { LayoutDashboard, BarChart3, Users, Megaphone, LogOut, Sparkles, Settings, Shield, ScrollText, Search, Handshake } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAuth } from "@/lib/auth-context";
import { useI18n } from "@/i18n/I18nProvider";
import { Button } from "@/components/ui/button";

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { role, signOut, user } = useAuth();
  const { t } = useI18n();
  const currentPath = useRouterState({ select: r => r.location.pathname });

  const items =
    role === "super_admin"
      ? [
          { title: "Super Admin", url: "/admin/dashboard", icon: Shield },
          { title: t.nav.clients as string, url: "/admin/clients", icon: Users },
          { title: "SEO Reports", url: "/seo", icon: Search },
          { title: "Settings", url: "/super-admin/settings/google-ads", icon: Settings },
          { title: "Audit log", url: "/super-admin/audit", icon: ScrollText },
        ]
      : role === "admin"
      ? [
          { title: t.nav.adminDashboard as string, url: "/admin/dashboard", icon: LayoutDashboard },
          { title: t.nav.clients as string, url: "/admin/clients", icon: Users },
          { title: "SEO Reports", url: "/seo", icon: Search },
          { title: "CRM", url: "/crm", icon: Handshake },
        ]
      : [
          { title: t.nav.dashboard as string, url: "/dashboard", icon: LayoutDashboard },
          { title: t.nav.campaigns as string, url: "/campaigns", icon: BarChart3 },
          { title: "SEO", url: "/seo", icon: Search },
        ];

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="px-3 py-4">
        <div className="flex items-center gap-2">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[image:var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-elegant)]">
            <Sparkles className="h-4 w-4" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold">Time SEO</span>
              <span className="text-[10px] text-muted-foreground">Ads Panel</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="flex items-center">
            <Megaphone className="h-3 w-3 mr-1" /> Menu
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map(item => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton asChild isActive={currentPath === item.url}>
                    <Link to={item.url} className="flex items-center gap-2">
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="p-2">
        {!collapsed && user?.email && (
          <div className="px-2 pb-2 text-xs text-muted-foreground truncate">{user.email}</div>
        )}
        <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={() => signOut()}>
          <LogOut className="h-4 w-4" />
          {!collapsed && <span>{t.nav.logout as string}</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}