import { Card, CardContent } from "@/components/ui/card";
import type { LucideIcon } from "lucide-react";

interface Props {
  label: string;
  value: string | number;
  icon: LucideIcon;
  accent?: string;
}

export function KpiCard({ label, value, icon: Icon, accent = "from-primary to-primary-glow" }: Props) {
  return (
    <Card className="overflow-hidden border-border/60 shadow-[var(--shadow-card)] transition-all hover:shadow-[var(--shadow-elegant)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</p>
            <p className="mt-2 text-2xl font-bold text-foreground">{value}</p>
          </div>
          <div className={`rounded-lg bg-gradient-to-br ${accent} p-2.5 text-primary-foreground shadow-md`}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}