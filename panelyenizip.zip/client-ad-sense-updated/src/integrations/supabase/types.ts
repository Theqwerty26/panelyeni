export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ad_metrics: {
        Row: {
          campaign_name: string
          campaign_status: string
          clicks: number
          client_id: string
          conversion_value: number
          conversions: number
          cost: number
          created_at: string
          date: string
          id: string
          impressions: number
          source: string
        }
        Insert: {
          campaign_name: string
          campaign_status?: string
          clicks?: number
          client_id: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date: string
          id?: string
          impressions?: number
          source?: string
        }
        Update: {
          campaign_name?: string
          campaign_status?: string
          clicks?: number
          client_id?: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date?: string
          id?: string
          impressions?: number
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "ad_metrics_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_provider_settings: {
        Row: {
          api_key: string | null
          base_url: string | null
          enabled: boolean
          id: string
          is_default: boolean
          max_tokens: number | null
          model: string | null
          provider: string
          system_prompt: string | null
          temperature: number | null
          updated_at: string
        }
        Insert: {
          api_key?: string | null
          base_url?: string | null
          enabled?: boolean
          id?: string
          is_default?: boolean
          max_tokens?: number | null
          model?: string | null
          provider: string
          system_prompt?: string | null
          temperature?: number | null
          updated_at?: string
        }
        Update: {
          api_key?: string | null
          base_url?: string | null
          enabled?: boolean
          id?: string
          is_default?: boolean
          max_tokens?: number | null
          model?: string | null
          provider?: string
          system_prompt?: string | null
          temperature?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      audience_metrics: {
        Row: {
          audience_name: string
          campaign_name: string | null
          clicks: number
          client_id: string
          conversion_value: number
          conversions: number
          cost: number
          created_at: string
          date: string
          id: string
          impressions: number
          source: string
        }
        Insert: {
          audience_name: string
          campaign_name?: string | null
          clicks?: number
          client_id: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date: string
          id?: string
          impressions?: number
          source?: string
        }
        Update: {
          audience_name?: string
          campaign_name?: string | null
          clicks?: number
          client_id?: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date?: string
          id?: string
          impressions?: number
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "audience_metrics_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: string
          ip_address: string | null
          role: string | null
          user_email: string | null
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          role?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: string
          ip_address?: string | null
          role?: string | null
          user_email?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      client_seo_properties: {
        Row: {
          client_id: string
          created_at: string
          ga4_property_id: string | null
          gsc_site_url: string | null
          id: string
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          ga4_property_id?: string | null
          gsc_site_url?: string | null
          id?: string
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          ga4_property_id?: string | null
          gsc_site_url?: string | null
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      crm_contacts: {
        Row: {
          id: string
          client_id: string | null
          first_name: string
          last_name: string
          email: string | null
          phone: string | null
          company: string | null
          job_title: string | null
          status: string
          source: string | null
          notes: string | null
          tags: string[]
          assigned_to: string | null
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          client_id?: string | null
          first_name: string
          last_name: string
          email?: string | null
          phone?: string | null
          company?: string | null
          job_title?: string | null
          status?: string
          source?: string | null
          notes?: string | null
          tags?: string[]
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          client_id?: string | null
          first_name?: string
          last_name?: string
          email?: string | null
          phone?: string | null
          company?: string | null
          job_title?: string | null
          status?: string
          source?: string | null
          notes?: string | null
          tags?: string[]
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      crm_deals: {
        Row: {
          id: string
          client_id: string | null
          contact_id: string | null
          title: string
          value: number
          currency: string
          stage: string
          probability: number
          close_date: string | null
          notes: string | null
          assigned_to: string | null
          created_by: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          client_id?: string | null
          contact_id?: string | null
          title: string
          value?: number
          currency?: string
          stage?: string
          probability?: number
          close_date?: string | null
          notes?: string | null
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          client_id?: string | null
          contact_id?: string | null
          title?: string
          value?: number
          currency?: string
          stage?: string
          probability?: number
          close_date?: string | null
          notes?: string | null
          assigned_to?: string | null
          created_by?: string | null
          created_at?: string
          updated_at?: string
        }
        Relationships: []
      }
      crm_activities: {
        Row: {
          id: string
          client_id: string | null
          contact_id: string
          deal_id: string | null
          type: string
          title: string
          description: string | null
          status: string
          due_at: string | null
          done_at: string | null
          created_by: string | null
          created_at: string
        }
        Insert: {
          id?: string
          client_id?: string | null
          contact_id: string
          deal_id?: string | null
          type?: string
          title: string
          description?: string | null
          status?: string
          due_at?: string | null
          done_at?: string | null
          created_by?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          client_id?: string | null
          contact_id?: string
          deal_id?: string | null
          type?: string
          title?: string
          description?: string | null
          status?: string
          due_at?: string | null
          done_at?: string | null
          created_by?: string | null
          created_at?: string
        }
        Relationships: []
      }
      clients: {
        Row: {
          ai_chat_enabled: boolean
          assigned_admin_id: string | null
          created_at: string
          data_source: string
          email: string
          google_ads_customer_id: string | null
          id: string
          last_synced_at: string | null
          logo_url: string | null
          manual_lock: boolean
          name: string
          user_id: string | null
        }
        Insert: {
          ai_chat_enabled?: boolean
          assigned_admin_id?: string | null
          created_at?: string
          data_source?: string
          email: string
          google_ads_customer_id?: string | null
          id?: string
          last_synced_at?: string | null
          logo_url?: string | null
          manual_lock?: boolean
          name: string
          user_id?: string | null
        }
        Update: {
          ai_chat_enabled?: boolean
          assigned_admin_id?: string | null
          created_at?: string
          data_source?: string
          email?: string
          google_ads_customer_id?: string | null
          id?: string
          last_synced_at?: string | null
          logo_url?: string | null
          manual_lock?: boolean
          name?: string
          user_id?: string | null
        }
        Relationships: []
      }
      email_logs: {
        Row: {
          created_at: string
          error: string | null
          id: string
          recipient: string
          sent_by: string | null
          status: string
          subject: string | null
          template_key: string | null
        }
        Insert: {
          created_at?: string
          error?: string | null
          id?: string
          recipient: string
          sent_by?: string | null
          status?: string
          subject?: string | null
          template_key?: string | null
        }
        Update: {
          created_at?: string
          error?: string | null
          id?: string
          recipient?: string
          sent_by?: string | null
          status?: string
          subject?: string | null
          template_key?: string | null
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          created_at: string
          enabled: boolean
          html: string
          id: string
          is_system: boolean
          key: string
          name: string
          subject: string
          text: string | null
          updated_at: string
          updated_by: string | null
          variables: Json
        }
        Insert: {
          created_at?: string
          enabled?: boolean
          html?: string
          id?: string
          is_system?: boolean
          key: string
          name: string
          subject: string
          text?: string | null
          updated_at?: string
          updated_by?: string | null
          variables?: Json
        }
        Update: {
          created_at?: string
          enabled?: boolean
          html?: string
          id?: string
          is_system?: boolean
          key?: string
          name?: string
          subject?: string
          text?: string | null
          updated_at?: string
          updated_by?: string | null
          variables?: Json
        }
        Relationships: []
      }
      ga4_metrics: {
        Row: {
          active_users: number
          avg_session_duration: number
          bounce_rate: number
          channel: string | null
          client_id: string
          conversions: number
          country: string | null
          created_at: string
          date: string
          device: string | null
          engaged_sessions: number
          id: string
          landing_page: string | null
          new_users: number
          sessions: number
          source: string
          source_medium: string | null
          total_revenue: number
        }
        Insert: {
          active_users?: number
          avg_session_duration?: number
          bounce_rate?: number
          channel?: string | null
          client_id: string
          conversions?: number
          country?: string | null
          created_at?: string
          date: string
          device?: string | null
          engaged_sessions?: number
          id?: string
          landing_page?: string | null
          new_users?: number
          sessions?: number
          source?: string
          source_medium?: string | null
          total_revenue?: number
        }
        Update: {
          active_users?: number
          avg_session_duration?: number
          bounce_rate?: number
          channel?: string | null
          client_id?: string
          conversions?: number
          country?: string | null
          created_at?: string
          date?: string
          device?: string | null
          engaged_sessions?: number
          id?: string
          landing_page?: string | null
          new_users?: number
          sessions?: number
          source?: string
          source_medium?: string | null
          total_revenue?: number
        }
        Relationships: []
      }
      google_ads_settings: {
        Row: {
          api_version: string | null
          client_id: string | null
          client_secret: string | null
          developer_token: string | null
          id: string
          last_test_account_name: string | null
          last_test_message: string | null
          last_test_status: string | null
          last_tested_at: string | null
          login_customer_id: string | null
          mcc_customer_id: string | null
          refresh_token: string | null
          singleton: boolean
          test_customer_id: string | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          api_version?: string | null
          client_id?: string | null
          client_secret?: string | null
          developer_token?: string | null
          id?: string
          last_test_account_name?: string | null
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          login_customer_id?: string | null
          mcc_customer_id?: string | null
          refresh_token?: string | null
          singleton?: boolean
          test_customer_id?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          api_version?: string | null
          client_id?: string | null
          client_secret?: string | null
          developer_token?: string | null
          id?: string
          last_test_account_name?: string | null
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          login_customer_id?: string | null
          mcc_customer_id?: string | null
          refresh_token?: string | null
          singleton?: boolean
          test_customer_id?: string | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      gsc_metrics: {
        Row: {
          clicks: number
          client_id: string
          country: string | null
          created_at: string
          ctr: number
          date: string
          device: string | null
          id: string
          impressions: number
          page: string | null
          position: number
          query: string | null
          source: string
        }
        Insert: {
          clicks?: number
          client_id: string
          country?: string | null
          created_at?: string
          ctr?: number
          date: string
          device?: string | null
          id?: string
          impressions?: number
          page?: string | null
          position?: number
          query?: string | null
          source?: string
        }
        Update: {
          clicks?: number
          client_id?: string
          country?: string | null
          created_at?: string
          ctr?: number
          date?: string
          device?: string | null
          id?: string
          impressions?: number
          page?: string | null
          position?: number
          query?: string | null
          source?: string
        }
        Relationships: []
      }
      keyword_metrics: {
        Row: {
          campaign_name: string | null
          clicks: number
          client_id: string
          conversion_value: number
          conversions: number
          cost: number
          created_at: string
          date: string
          id: string
          impressions: number
          keyword: string
          match_type: string | null
          quality_score: number | null
          source: string
        }
        Insert: {
          campaign_name?: string | null
          clicks?: number
          client_id: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date: string
          id?: string
          impressions?: number
          keyword: string
          match_type?: string | null
          quality_score?: number | null
          source?: string
        }
        Update: {
          campaign_name?: string | null
          clicks?: number
          client_id?: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date?: string
          id?: string
          impressions?: number
          keyword?: string
          match_type?: string | null
          quality_score?: number | null
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "keyword_metrics_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string | null
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message?: string | null
          read?: boolean
          title: string
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string | null
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      product_metrics: {
        Row: {
          brand: string | null
          clicks: number
          client_id: string
          conversion_value: number
          conversions: number
          cost: number
          created_at: string
          date: string
          id: string
          impressions: number
          merchant_center_id: string | null
          price: number | null
          product_category: string | null
          product_id: string | null
          product_title: string
          source: string
        }
        Insert: {
          brand?: string | null
          clicks?: number
          client_id: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date: string
          id?: string
          impressions?: number
          merchant_center_id?: string | null
          price?: number | null
          product_category?: string | null
          product_id?: string | null
          product_title: string
          source?: string
        }
        Update: {
          brand?: string | null
          clicks?: number
          client_id?: string
          conversion_value?: number
          conversions?: number
          cost?: number
          created_at?: string
          date?: string
          id?: string
          impressions?: number
          merchant_center_id?: string | null
          price?: number | null
          product_category?: string | null
          product_id?: string | null
          product_title?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "product_metrics_client_id_fkey"
            columns: ["client_id"]
            isOneToOne: false
            referencedRelation: "clients"
            referencedColumns: ["id"]
          },
        ]
      }
      report_templates: {
        Row: {
          blocks: Json
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          is_default: boolean
          name: string
          updated_at: string
        }
        Insert: {
          blocks?: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          blocks?: Json
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          is_default?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      seo_provider_settings: {
        Row: {
          base_url: string | null
          config: Json
          default_database: string | null
          enabled: boolean
          id: string
          last_test_message: string | null
          last_test_status: string | null
          last_tested_at: string | null
          provider: string
          rate_limit_per_minute: number | null
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          base_url?: string | null
          config?: Json
          default_database?: string | null
          enabled?: boolean
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          provider: string
          rate_limit_per_minute?: number | null
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          base_url?: string | null
          config?: Json
          default_database?: string | null
          enabled?: boolean
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          provider?: string
          rate_limit_per_minute?: number | null
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      seo_reports: {
        Row: {
          client_id: string
          created_at: string
          created_by: string | null
          data: Json
          id: string
          pdf_url: string | null
          period_end: string
          period_start: string
          status: string
          summary: string | null
          template_id: string | null
          title: string
          updated_at: string
        }
        Insert: {
          client_id: string
          created_at?: string
          created_by?: string | null
          data?: Json
          id?: string
          pdf_url?: string | null
          period_end: string
          period_start: string
          status?: string
          summary?: string | null
          template_id?: string | null
          title: string
          updated_at?: string
        }
        Update: {
          client_id?: string
          created_at?: string
          created_by?: string | null
          data?: Json
          id?: string
          pdf_url?: string | null
          period_end?: string
          period_start?: string
          status?: string
          summary?: string | null
          template_id?: string | null
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      seo_settings: {
        Row: {
          ga4_enabled: boolean
          google_client_id: string | null
          google_client_secret: string | null
          google_refresh_token: string | null
          gsc_enabled: boolean
          id: string
          last_test_message: string | null
          last_test_status: string | null
          last_tested_at: string | null
          singleton: boolean
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          ga4_enabled?: boolean
          google_client_id?: string | null
          google_client_secret?: string | null
          google_refresh_token?: string | null
          gsc_enabled?: boolean
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          singleton?: boolean
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          ga4_enabled?: boolean
          google_client_id?: string | null
          google_client_secret?: string | null
          google_refresh_token?: string | null
          gsc_enabled?: boolean
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          singleton?: boolean
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      serp_competitors: {
        Row: {
          client_id: string
          created_at: string
          domain: string
          id: string
          notes: string | null
        }
        Insert: {
          client_id: string
          created_at?: string
          domain: string
          id?: string
          notes?: string | null
        }
        Update: {
          client_id?: string
          created_at?: string
          domain?: string
          id?: string
          notes?: string | null
        }
        Relationships: []
      }
      serp_results: {
        Row: {
          client_id: string
          competition: number | null
          country: string | null
          cpc: number | null
          created_at: string
          device: string
          difficulty: number | null
          fetched_at: string
          id: string
          keyword: string
          language: string | null
          position: number | null
          previous_position: number | null
          provider: string
          raw: Json | null
          search_engine: string
          search_volume: number | null
          url: string | null
        }
        Insert: {
          client_id: string
          competition?: number | null
          country?: string | null
          cpc?: number | null
          created_at?: string
          device?: string
          difficulty?: number | null
          fetched_at?: string
          id?: string
          keyword: string
          language?: string | null
          position?: number | null
          previous_position?: number | null
          provider?: string
          raw?: Json | null
          search_engine?: string
          search_volume?: number | null
          url?: string | null
        }
        Update: {
          client_id?: string
          competition?: number | null
          country?: string | null
          cpc?: number | null
          created_at?: string
          device?: string
          difficulty?: number | null
          fetched_at?: string
          id?: string
          keyword?: string
          language?: string | null
          position?: number | null
          previous_position?: number | null
          provider?: string
          raw?: Json | null
          search_engine?: string
          search_volume?: number | null
          url?: string | null
        }
        Relationships: []
      }
      smtp_settings: {
        Row: {
          enabled: boolean
          from_email: string | null
          from_name: string | null
          host: string | null
          id: string
          last_test_message: string | null
          last_test_status: string | null
          last_tested_at: string | null
          password: string | null
          port: number | null
          secure: boolean | null
          singleton: boolean
          updated_at: string
          updated_by: string | null
          username: string | null
        }
        Insert: {
          enabled?: boolean
          from_email?: string | null
          from_name?: string | null
          host?: string | null
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          password?: string | null
          port?: number | null
          secure?: boolean | null
          singleton?: boolean
          updated_at?: string
          updated_by?: string | null
          username?: string | null
        }
        Update: {
          enabled?: boolean
          from_email?: string | null
          from_name?: string | null
          host?: string | null
          id?: string
          last_test_message?: string | null
          last_test_status?: string | null
          last_tested_at?: string | null
          password?: string | null
          port?: number | null
          secure?: boolean | null
          singleton?: boolean
          updated_at?: string
          updated_by?: string | null
          username?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin_or_super: { Args: { _user_id: string }; Returns: boolean }
      is_super_admin: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "client" | "super_admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "client", "super_admin"],
    },
  },
} as const
